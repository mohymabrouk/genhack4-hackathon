# -*- coding: utf-8 -*-
"""
GenHack Week 4 - 4 Models with Quantile Regression
===================================================
1. XGBoost bias correction (48 combinations)
2. Random Forest UHI prediction (48 combinations)
3. Ridge regression downscaling (50 combinations)
4. Quantile Regression uncertainty quantification (40 combinations) ⭐ NEW

Author: GenHack Team 2025
Date: December 2025
"""

import os
import sys
import json
import warnings
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from datetime import datetime

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, TimeSeriesSplit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
import xgboost as xgb

warnings.filterwarnings('ignore')
plt.style.use('seaborn-v0_8-darkgrid')


# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    """Simplified configuration."""
    BASE_DIR = r"C:\Users\userpc\Desktop\main\ALL_EXTRACTED\main"
    OUTPUT_DIR = os.path.join(BASE_DIR, "week4_simple_models")
    
    # Modeling parameters
    TEST_SIZE = 0.2
    RANDOM_STATE = 42
    CV_FOLDS = 5
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# DATA LOADING
# ============================================================
class DataLoader:
    """Simple data loading."""
    
    def __init__(self, city_name: str):
        self.city = city_name
        self.cname = city_name.replace(" ", "_")
        self.features_path = os.path.join(
            Config.BASE_DIR, "outputs", f"features_{self.cname}.csv"
        )
        self.metrics_path = os.path.join(
            Config.BASE_DIR, "outputs", f"metrics_{self.cname}.json"
        )
    
    def load_data(self) -> Tuple[pd.DataFrame, Dict]:
        """Load features and metrics."""
        if not os.path.exists(self.features_path):
            raise FileNotFoundError(f"File not found: {self.features_path}")
        
        df = pd.read_csv(self.features_path)
        df['date'] = pd.to_datetime(df['date'])
        df.set_index('date', inplace=True)
        df = df.sort_index()
        
        if df.index.duplicated().any():
            df = df[~df.index.duplicated(keep='first')]
        
        metrics = {}
        if os.path.exists(self.metrics_path):
            with open(self.metrics_path, 'r') as f:
                metrics = json.load(f)
        
        print(f"Loaded {len(df)} rows, {len(df.columns)} columns")
        return df, metrics
    
    def create_basic_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create minimal feature set to prevent overfitting."""
        df_eng = df.copy()
        
        df_eng['day_sin'] = np.sin(2 * np.pi * df_eng.index.dayofyear / 365.25)
        df_eng['day_cos'] = np.cos(2 * np.pi * df_eng.index.dayofyear / 365.25)
        df_eng['month'] = df_eng.index.month
        
        essential_cols = [
            'TX_C_city_mean', 'TN_C_city_mean',
            'ERA5_t2m_max_C', 'ERA5_t2m_min_C',
            'FG_ms_city_mean', 'PP_hPa_city_mean',
            'NDVI_city', 'day_sin', 'day_cos', 'month'
        ]
        
        available_cols = [c for c in essential_cols if c in df_eng.columns]
        df_eng = df_eng[available_cols]
        df_eng = df_eng.fillna(method='ffill').fillna(method='bfill')
        
        print(f"Engineered features: {len(df_eng.columns)} columns")
        return df_eng


class XGBoostBiasCorrector:
    """XGBoost with exhaustive 48-combination grid search."""
    
    def __init__(self):
        self.model = None
        self.scaler = None
        self.best_params = {}
        self.grid_search_results = {}
    
    def get_param_grid(self):
        """Generate 48 diverse parameter combinations."""
        params_list = [
            # Ultra-conservative (prevent overfitting)
            {'n_estimators': 20, 'max_depth': 2, 'learning_rate': 0.01, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 10, 'gamma': 0.3},
            {'n_estimators': 30, 'max_depth': 2, 'learning_rate': 0.01, 'subsample': 0.6, 'colsample_bytree': 0.6, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 10, 'gamma': 0.2},
            {'n_estimators': 25, 'max_depth': 2, 'learning_rate': 0.01, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 5.0, 'min_child_weight': 7, 'gamma': 0.3},
            {'n_estimators': 20, 'max_depth': 3, 'learning_rate': 0.01, 'subsample': 0.6, 'colsample_bytree': 0.7, 'reg_alpha': 5.0, 'reg_lambda': 3.0, 'min_child_weight': 10, 'gamma': 0.2},
            
            # Conservative shallow
            {'n_estimators': 30, 'max_depth': 2, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 40, 'max_depth': 2, 'learning_rate': 0.02, 'subsample': 0.8, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 35, 'max_depth': 2, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.8, 'reg_alpha': 2.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 30, 'max_depth': 3, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 2.0, 'min_child_weight': 7, 'gamma': 0.1},
            
            # Moderate depth 2
            {'n_estimators': 40, 'max_depth': 2, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 50, 'max_depth': 2, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 45, 'max_depth': 2, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 3.0, 'min_child_weight': 5, 'gamma': 0},
            {'n_estimators': 40, 'max_depth': 2, 'learning_rate': 0.03, 'subsample': 0.9, 'colsample_bytree': 0.8, 'reg_alpha': 1.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            
            # Moderate depth 3
            {'n_estimators': 40, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 50, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 45, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 3.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 40, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.6, 'colsample_bytree': 0.6, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 7, 'gamma': 0.2},
            
            # Balanced configurations
            {'n_estimators': 50, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 1.0, 'reg_lambda': 1.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 60, 'max_depth': 2, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 50, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 60, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            
            # Higher learning rate, constrained
            {'n_estimators': 30, 'max_depth': 2, 'learning_rate': 0.05, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 40, 'max_depth': 2, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 30, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 40, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.7, 'colsample_bytree': 0.8, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            
            # More trees, shallow
            {'n_estimators': 60, 'max_depth': 2, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 75, 'max_depth': 2, 'learning_rate': 0.01, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 60, 'max_depth': 2, 'learning_rate': 0.02, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 1.0, 'reg_lambda': 1.0, 'min_child_weight': 5, 'gamma': 0},
            {'n_estimators': 75, 'max_depth': 2, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            
            # Depth 4 explorations
            {'n_estimators': 30, 'max_depth': 4, 'learning_rate': 0.02, 'subsample': 0.6, 'colsample_bytree': 0.6, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 10, 'gamma': 0.3},
            {'n_estimators': 40, 'max_depth': 4, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 30, 'max_depth': 4, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 40, 'max_depth': 4, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            
            # Low regularization tests
            {'n_estimators': 50, 'max_depth': 2, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 0.5, 'reg_lambda': 0.5, 'min_child_weight': 3, 'gamma': 0},
            {'n_estimators': 40, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 1.0, 'reg_lambda': 1.0, 'min_child_weight': 3, 'gamma': 0},
            {'n_estimators': 50, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.9, 'colsample_bytree': 0.9, 'reg_alpha': 0.5, 'reg_lambda': 0.5, 'min_child_weight': 3, 'gamma': 0},
            {'n_estimators': 60, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 1.0, 'reg_lambda': 1.0, 'min_child_weight': 3, 'gamma': 0},
            
            # High regularization tests
            {'n_estimators': 50, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 60, 'max_depth': 3, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 7, 'gamma': 0.3},
            {'n_estimators': 40, 'max_depth': 4, 'learning_rate': 0.02, 'subsample': 0.6, 'colsample_bytree': 0.6, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 10, 'gamma': 0.3},
            {'n_estimators': 50, 'max_depth': 4, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            
            # Aggressive learning
            {'n_estimators': 30, 'max_depth': 3, 'learning_rate': 0.07, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 20, 'max_depth': 2, 'learning_rate': 0.1, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 30, 'max_depth': 2, 'learning_rate': 0.07, 'subsample': 0.8, 'colsample_bytree': 0.8, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            {'n_estimators': 40, 'max_depth': 3, 'learning_rate': 0.07, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0, 'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1},
            
            # Depth 5 explorations
            {'n_estimators': 30, 'max_depth': 5, 'learning_rate': 0.01, 'subsample': 0.6, 'colsample_bytree': 0.6, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 10, 'gamma': 0.3},
            {'n_estimators': 40, 'max_depth': 5, 'learning_rate': 0.02, 'subsample': 0.6, 'colsample_bytree': 0.6, 'reg_alpha': 5.0, 'reg_lambda': 5.0, 'min_child_weight': 10, 'gamma': 0.3},
            {'n_estimators': 30, 'max_depth': 5, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
            {'n_estimators': 40, 'max_depth': 5, 'learning_rate': 0.02, 'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 3.0, 'reg_lambda': 3.0, 'min_child_weight': 7, 'gamma': 0.2},
        ]
        
        return params_list
    
    def grid_search_cv(self, X, y, n_splits=5):
        """Perform exhaustive 48-combination grid search."""
        from sklearn.model_selection import TimeSeriesSplit
        
        print(f"  EXHAUSTIVE GRID SEARCH: Testing 48 parameter combinations...")
        print(f"  Using {n_splits}-fold Time Series CV\n")
        
        params_list = self.get_param_grid()
        
        tscv = TimeSeriesSplit(n_splits=n_splits)
        best_score = float('inf')
        best_params = None
        all_results = []
        
        for idx, params in enumerate(params_list, 1):
            if idx % 10 == 1:
                print(f"  Progress: {idx}/48 combinations tested...")
            
            fold_scores = []
            fold_r2 = []
            
            for fold, (train_idx, val_idx) in enumerate(tscv.split(X), 1):
                X_train_fold = X.iloc[train_idx]
                y_train_fold = y.iloc[train_idx]
                X_val_fold = X.iloc[val_idx]
                y_val_fold = y.iloc[val_idx]
                
                scaler = StandardScaler()
                X_train_scaled = scaler.fit_transform(X_train_fold)
                X_val_scaled = scaler.transform(X_val_fold)
                
                model = xgb.XGBRegressor(
                    **params,
                    early_stopping_rounds=15,
                    random_state=Config.RANDOM_STATE,
                    n_jobs=-1
                )
                
                model.fit(
                    X_train_scaled, y_train_fold,
                    eval_set=[(X_val_scaled, y_val_fold)],
                    verbose=False
                )
                
                y_pred = model.predict(X_val_scaled)
                rmse = np.sqrt(mean_squared_error(y_val_fold, y_pred))
                r2 = r2_score(y_val_fold, y_pred)
                
                fold_scores.append(rmse)
                fold_r2.append(r2)
            
            mean_rmse = np.mean(fold_scores)
            std_rmse = np.std(fold_scores)
            mean_r2 = np.mean(fold_r2)
            std_r2 = np.std(fold_r2)
            
            all_results.append({
                'config_id': idx,
                'params': params,
                'mean_rmse': mean_rmse,
                'std_rmse': std_rmse,
                'mean_r2': mean_r2,
                'std_r2': std_r2
            })
            
            if mean_rmse < best_score:
                best_score = mean_rmse
                best_params = params
                print(f"    Config #{idx}: NEW BEST RMSE = {best_score:.4f}°C (R²={mean_r2:.4f})")
        
        self.best_params = best_params
        self.grid_search_results = {
            'best_rmse': best_score,
            'best_params': best_params,
            'all_results': all_results
        }
        
        print(f"\n  ✓ GRID SEARCH COMPLETE!")
        print(f"  BEST PARAMETERS:")
        for param, value in best_params.items():
            print(f"    {param}: {value}")
        print(f"  Best CV RMSE: {best_score:.4f}°C\n")
        
        return best_params
    
    def train(self, X_train, y_train, params=None):
        """Train with optimal parameters."""
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        
        if params is None:
            params = self.best_params if self.best_params else {
                'n_estimators': 50, 'max_depth': 3, 'learning_rate': 0.03,
                'subsample': 0.7, 'colsample_bytree': 0.7, 'reg_alpha': 2.0,
                'reg_lambda': 2.0, 'min_child_weight': 5, 'gamma': 0.1
            }
        
        self.model = xgb.XGBRegressor(
            **params,
            early_stopping_rounds=15,
            random_state=Config.RANDOM_STATE,
            n_jobs=-1
        )
        
        if len(X_train) > 100:
            X_tr, X_val, y_tr, y_val = train_test_split(
                X_train_scaled, y_train, test_size=0.2, random_state=Config.RANDOM_STATE
            )
            self.model.fit(X_tr, y_tr, eval_set=[(X_val, y_val)], verbose=False)
        else:
            self.model.fit(X_train_scaled, y_train)
        
        return self.model
    
    def predict(self, X):
        """Make predictions."""
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)
    
    def correct(self, df, era5_col, station_col, feature_cols):
        """Correct ERA5 bias with exhaustive grid search."""
        print(f"\n{'='*70}")
        print(f"XGBOOST BIAS CORRECTION: {era5_col} -> {station_col}")
        print(f"{'='*70}")
        
        df_sub = df[feature_cols + [era5_col, station_col]].dropna()
        if len(df_sub) < 50:
            print(f"  Not enough data: {len(df_sub)} samples")
            return None, {}
        
        X = df_sub[feature_cols + [era5_col]]
        y = df_sub[station_col]
        
        print(f"Dataset: {len(X)} samples, {len(feature_cols)+1} features")
        
        # Grid search
        final_params = self.grid_search_cv(X, y, n_splits=5)
        
        # Train-test split
        split_idx = int(len(X) * (1 - Config.TEST_SIZE))
        X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
        y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
        
        print(f"Final model training on {len(X_train)} samples...")
        self.train(X_train, y_train, params=final_params)
        
        # Predictions
        y_pred_train = self.predict(X_train)
        y_pred_test = self.predict(X_test)
        
        # Metrics
        train_rmse = np.sqrt(mean_squared_error(y_train, y_pred_train))
        test_rmse = np.sqrt(mean_squared_error(y_test, y_pred_test))
        train_r2 = r2_score(y_train, y_pred_train)
        test_r2 = r2_score(y_test, y_pred_test)
        
        metrics = {
            'train_rmse': train_rmse,
            'test_rmse': test_rmse,
            'train_r2': train_r2,
            'test_r2': test_r2,
            'train_mae': mean_absolute_error(y_train, y_pred_train),
            'test_mae': mean_absolute_error(y_test, y_pred_test),
            'overfitting_gap': train_r2 - test_r2,
            'best_params': final_params,
            'grid_search_results': self.grid_search_results,
            'n_train': len(y_train),
            'n_test': len(y_test),
            'n_combinations_tested': 48
        }
        
        # Apply correction
        X_full = df[feature_cols + [era5_col]].fillna(method='ffill')
        corrected = self.predict(X_full)
        corrected_series = pd.Series(corrected, index=df.index, name=f'{era5_col}_corrected')
        
        print(f"\nFINAL PERFORMANCE:")
        print(f"  Train: RMSE={train_rmse:.3f}°C, R²={train_r2:.3f}")
        print(f"  Test:  RMSE={test_rmse:.3f}°C, R²={test_r2:.3f}")
        print(f"  Overfitting gap: {metrics['overfitting_gap']:.3f}")
        print(f"{'='*70}\n")
        
        return corrected_series, metrics


class RandomForestUHIPredictor:
    """Random Forest with exhaustive 48-combination grid search."""
    
    def __init__(self):
        self.model = None
        self.scaler = None
        self.best_params = {}
        self.grid_search_results = {}
    
    def get_param_grid(self):
        """Generate 48 diverse parameter combinations for Random Forest."""
        params_list = [
            # Ultra-conservative
            {'n_estimators': 20, 'max_depth': 2, 'min_samples_split': 30, 'min_samples_leaf': 15, 'max_features': 'sqrt', 'max_samples': 0.6},
            {'n_estimators': 30, 'max_depth': 2, 'min_samples_split': 25, 'min_samples_leaf': 10, 'max_features': 'sqrt', 'max_samples': 0.6},
            {'n_estimators': 25, 'max_depth': 2, 'min_samples_split': 30, 'min_samples_leaf': 10, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 20, 'max_depth': 3, 'min_samples_split': 25, 'min_samples_leaf': 15, 'max_features': 'sqrt', 'max_samples': 0.6},
            
            # Conservative
            {'n_estimators': 30, 'max_depth': 3, 'min_samples_split': 20, 'min_samples_leaf': 10, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 40, 'max_depth': 2, 'min_samples_split': 20, 'min_samples_leaf': 10, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 35, 'max_depth': 3, 'min_samples_split': 20, 'min_samples_leaf': 8, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 30, 'max_depth': 3, 'min_samples_split': 25, 'min_samples_leaf': 10, 'max_features': 'log2', 'max_samples': 0.7},
            
            # Moderate depth 3
            {'n_estimators': 40, 'max_depth': 3, 'min_samples_split': 15, 'min_samples_leaf': 8, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 50, 'max_depth': 3, 'min_samples_split': 15, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 45, 'max_depth': 3, 'min_samples_split': 15, 'min_samples_leaf': 8, 'max_features': 'log2', 'max_samples': 0.8},
            {'n_estimators': 40, 'max_depth': 3, 'min_samples_split': 20, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.8},
            
            # Moderate depth 4
            {'n_estimators': 40, 'max_depth': 4, 'min_samples_split': 20, 'min_samples_leaf': 10, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 50, 'max_depth': 4, 'min_samples_split': 15, 'min_samples_leaf': 8, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 45, 'max_depth': 4, 'min_samples_split': 15, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 40, 'max_depth': 4, 'min_samples_split': 20, 'min_samples_leaf': 8, 'max_features': 'log2', 'max_samples': 0.8},
            
            # Balanced
            {'n_estimators': 50, 'max_depth': 4, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.8},
            {'n_estimators': 60, 'max_depth': 3, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.8},
            {'n_estimators': 50, 'max_depth': 4, 'min_samples_split': 15, 'min_samples_leaf': 5, 'max_features': 'log2', 'max_samples': 0.8},
            {'n_estimators': 60, 'max_depth': 4, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.7},
            
            # More trees
            {'n_estimators': 60, 'max_depth': 3, 'min_samples_split': 15, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 75, 'max_depth': 2, 'min_samples_split': 15, 'min_samples_leaf': 8, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 60, 'max_depth': 3, 'min_samples_split': 15, 'min_samples_leaf': 8, 'max_features': 'sqrt', 'max_samples': 0.8},
            {'n_estimators': 75, 'max_depth': 3, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.7},
            
            # Depth 5
            {'n_estimators': 40, 'max_depth': 5, 'min_samples_split': 20, 'min_samples_leaf': 10, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 50, 'max_depth': 5, 'min_samples_split': 15, 'min_samples_leaf': 8, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 45, 'max_depth': 5, 'min_samples_split': 15, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 40, 'max_depth': 5, 'min_samples_split': 20, 'min_samples_leaf': 8, 'max_features': 'log2', 'max_samples': 0.8},
            
            # Depth 6
            {'n_estimators': 40, 'max_depth': 6, 'min_samples_split': 20, 'min_samples_leaf': 10, 'max_features': 'sqrt', 'max_samples': 0.6},
            {'n_estimators': 50, 'max_depth': 6, 'min_samples_split': 20, 'min_samples_leaf': 10, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 30, 'max_depth': 6, 'min_samples_split': 25, 'min_samples_leaf': 15, 'max_features': 'sqrt', 'max_samples': 0.6},
            {'n_estimators': 40, 'max_depth': 6, 'min_samples_split': 20, 'min_samples_leaf': 8, 'max_features': 'sqrt', 'max_samples': 0.7},
            
            # Feature variations
            {'n_estimators': 50, 'max_depth': 4, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 0.5, 'max_samples': 0.8},
            {'n_estimators': 40, 'max_depth': 4, 'min_samples_split': 15, 'min_samples_leaf': 5, 'max_features': 0.7, 'max_samples': 0.8},
            {'n_estimators': 50, 'max_depth': 3, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 0.7, 'max_samples': 0.8},
            {'n_estimators': 60, 'max_depth': 3, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 0.5, 'max_samples': 0.8},
            
            # High sampling
            {'n_estimators': 50, 'max_depth': 3, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.9},
            {'n_estimators': 60, 'max_depth': 4, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.9},
            {'n_estimators': 40, 'max_depth': 4, 'min_samples_split': 15, 'min_samples_leaf': 5, 'max_features': 'log2', 'max_samples': 0.9},
            {'n_estimators': 50, 'max_depth': 4, 'min_samples_split': 15, 'min_samples_leaf': 8, 'max_features': 'sqrt', 'max_samples': 0.9},
            
            # Low split constraints
            {'n_estimators': 50, 'max_depth': 4, 'min_samples_split': 5, 'min_samples_leaf': 2, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 60, 'max_depth': 4, 'min_samples_split': 5, 'min_samples_leaf': 2, 'max_features': 'sqrt', 'max_samples': 0.8},
            {'n_estimators': 40, 'max_depth': 5, 'min_samples_split': 10, 'min_samples_leaf': 2, 'max_features': 'sqrt', 'max_samples': 0.7},
            {'n_estimators': 50, 'max_depth': 5, 'min_samples_split': 10, 'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.8},
            
            # Mixed configurations
            {'n_estimators': 45, 'max_depth': 4, 'min_samples_split': 12, 'min_samples_leaf': 6, 'max_features': 'sqrt', 'max_samples': 0.75},
            {'n_estimators': 55, 'max_depth': 3, 'min_samples_split': 12, 'min_samples_leaf': 6, 'max_features': 'log2', 'max_samples': 0.75},
            {'n_estimators': 45, 'max_depth': 4, 'min_samples_split': 18, 'min_samples_leaf': 7, 'max_features': 'sqrt', 'max_samples': 0.75},
            {'n_estimators': 55, 'max_depth': 4, 'min_samples_split': 12, 'min_samples_leaf': 5, 'max_features': 0.7, 'max_samples': 0.8},
        ]
        
        return params_list
    
    def create_uhi_target(self, df, metrics):
        """Create simple UHI target series."""
        uhi_value = 2.0
        if 'uhi_distance_summer_night' in metrics:
            uhi_value = metrics['uhi_distance_summer_night']['mean']
        elif 't2m_vs_TX' in metrics:
            uhi_value = -metrics['t2m_vs_TX']['mean_bias']
        
        doy = df.index.dayofyear
        seasonal = 0.5 * np.sin(2 * np.pi * (doy - 172) / 365)
        
        np.random.seed(Config.RANDOM_STATE)
        noise = np.random.normal(0, 0.2, len(df))
        
        uhi_series = uhi_value + seasonal + noise
        uhi_series = np.clip(uhi_series, 0.5, 3.5)
        
        return pd.Series(uhi_series, index=df.index, name='UHI')
    
    def grid_search_cv(self, X, y, n_splits=5):
        """Perform exhaustive 48-combination grid search for Random Forest."""
        from sklearn.model_selection import TimeSeriesSplit
        
        print(f"  EXHAUSTIVE GRID SEARCH: Testing 48 parameter combinations...")
        print(f"  Using {n_splits}-fold Time Series CV\n")
        
        params_list = self.get_param_grid()
        
        tscv = TimeSeriesSplit(n_splits=n_splits)
        best_score = float('inf')
        best_params = None
        all_results = []
        
        for idx, params in enumerate(params_list, 1):
            if idx % 10 == 1:
                print(f"  Progress: {idx}/48 combinations tested...")
            
            fold_scores = []
            fold_r2 = []
            
            for fold, (train_idx, val_idx) in enumerate(tscv.split(X), 1):
                X_train_fold = X.iloc[train_idx]
                y_train_fold = y.iloc[train_idx]
                X_val_fold = X.iloc[val_idx]
                y_val_fold = y.iloc[val_idx]
                
                scaler = StandardScaler()
                X_train_scaled = scaler.fit_transform(X_train_fold)
                X_val_scaled = scaler.transform(X_val_fold)
                
                model = RandomForestRegressor(
                    **params,
                    random_state=Config.RANDOM_STATE,
                    n_jobs=-1
                )
                
                model.fit(X_train_scaled, y_train_fold)
                
                y_pred = model.predict(X_val_scaled)
                rmse = np.sqrt(mean_squared_error(y_val_fold, y_pred))
                r2 = r2_score(y_val_fold, y_pred)
                
                fold_scores.append(rmse)
                fold_r2.append(r2)
            
            mean_rmse = np.mean(fold_scores)
            std_rmse = np.std(fold_scores)
            mean_r2 = np.mean(fold_r2)
            std_r2 = np.std(fold_r2)
            
            all_results.append({
                'config_id': idx,
                'params': params,
                'mean_rmse': mean_rmse,
                'std_rmse': std_rmse,
                'mean_r2': mean_r2,
                'std_r2': std_r2
            })
            
            if mean_rmse < best_score:
                best_score = mean_rmse
                best_params = params
                print(f"    Config #{idx}: NEW BEST RMSE = {best_score:.4f}°C (R²={mean_r2:.4f})")
        
        self.best_params = best_params
        self.grid_search_results = {
            'best_rmse': best_score,
            'best_params': best_params,
            'all_results': all_results
        }
        
        print(f"\n  ✓ GRID SEARCH COMPLETE!")
        print(f"  BEST PARAMETERS:")
        for param, value in best_params.items():
            print(f"    {param}: {value}")
        print(f"  Best CV RMSE: {best_score:.4f}°C\n")
        
        return best_params
    
    def train(self, X_train, y_train, params=None):
        """Train Random Forest with optimal parameters."""
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        
        if params is None:
            params = self.best_params if self.best_params else {
                'n_estimators': 50, 'max_depth': 4, 'min_samples_split': 10,
                'min_samples_leaf': 5, 'max_features': 'sqrt', 'max_samples': 0.8
            }
        
        self.model = RandomForestRegressor(
            **params,
            random_state=Config.RANDOM_STATE,
            n_jobs=-1
        )
        
        self.model.fit(X_train_scaled, y_train)
        return self.model
    
    def predict(self, X):
        """Make predictions."""
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)
    
    def run(self, df, uhi_series, feature_cols):
        """Run UHI prediction with exhaustive grid search."""
        print(f"\n{'='*70}")
        print(f"RANDOM FOREST UHI PREDICTION")
        print(f"{'='*70}")
        
        df_sub = df[feature_cols].copy()
        df_sub['UHI'] = uhi_series
        df_sub = df_sub.dropna()
        
        if len(df_sub) < 50:
            print(f"  Not enough data: {len(df_sub)} samples")
            return None, {}
        
        X = df_sub[feature_cols]
        y = df_sub['UHI']
        
        print(f"Dataset: {len(X)} samples, {len(feature_cols)} features")
        
        # Grid search
        final_params = self.grid_search_cv(X, y, n_splits=5)
        
        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=Config.TEST_SIZE, random_state=Config.RANDOM_STATE
        )
        
        # Train model
        self.train(X_train, y_train, params=final_params)
        
        # Predict
        y_pred_train = self.predict(X_train)
        y_pred_test = self.predict(X_test)
        
        # Calculate metrics
        metrics = {
            'train_rmse': np.sqrt(mean_squared_error(y_train, y_pred_train)),
            'test_rmse': np.sqrt(mean_squared_error(y_test, y_pred_test)),
            'train_r2': r2_score(y_train, y_pred_train),
            'test_r2': r2_score(y_test, y_pred_test),
            'best_params': final_params,
            'grid_search_results': self.grid_search_results,
            'n_combinations_tested': 48,
            'feature_importance': dict(zip(feature_cols, self.model.feature_importances_))
        }
        
        # Predict for full dataset
        X_full = df[feature_cols].fillna(method='ffill')
        predictions = self.predict(X_full)
        predicted_series = pd.Series(predictions, index=df.index, name='UHI_predicted')
        
        print(f"\nFINAL PERFORMANCE:")
        print(f"  Train: RMSE={metrics['train_rmse']:.3f}°C, R²={metrics['train_r2']:.3f}")
        print(f"  Test:  RMSE={metrics['test_rmse']:.3f}°C, R²={metrics['test_r2']:.3f}")
        print(f"{'='*70}\n")
        
        return predicted_series, metrics











class ComprehensiveExporter:
    """Export all model results, plots, and data in structured format."""
    
    def __init__(self, output_dir, city_name):
        self.output_dir = output_dir
        self.city_name = city_name
        self.export_data = {
            'metadata': {},
            'models': {},
            'plots': {},
            'datasets': {},
            'cv_results': {},
            'feature_importance': {}
        }
        
        # Create subdirectories
        self.plots_dir = os.path.join(output_dir, "plots")
        self.data_dir = os.path.join(output_dir, "data")
        self.cv_dir = os.path.join(output_dir, "cv_results")
        
        for d in [self.plots_dir, self.data_dir, self.cv_dir]:
            os.makedirs(d, exist_ok=True)
    
    def add_metadata(self, df, config):
        """Store metadata about the analysis."""
        self.export_data['metadata'] = {
            'city': self.city_name,
            'timestamp': datetime.now().isoformat(),
            'n_samples': len(df),
            'date_range': {
                'start': str(df.index.min()),
                'end': str(df.index.max())
            },
            'features': list(df.columns),
            'config': {
                'test_size': config.TEST_SIZE,
                'random_state': config.RANDOM_STATE,
                'cv_folds': config.CV_FOLDS
            }
        }
    
    def save_model_results(self, model_name, metrics, predictions, y_true, best_params=None):
        """Save comprehensive model results."""
        model_data = {
            'metrics': self._serialize_metrics(metrics),
            'predictions_stats': {
                'mean': float(np.mean(predictions)),
                'std': float(np.std(predictions)),
                'min': float(np.min(predictions)),
                'max': float(np.max(predictions))
            },
            'residuals_stats': self._calculate_residual_stats(y_true, predictions)
        }
        
        if best_params:
            model_data['best_params'] = best_params
        
        self.export_data['models'][model_name] = model_data
        
        # Save predictions to CSV
        pred_df = pd.DataFrame({
            'y_true': y_true,
            'y_pred': predictions,
            'residual': y_true - predictions,
            'abs_error': np.abs(y_true - predictions)
        })
        pred_path = os.path.join(self.data_dir, f"{model_name}_predictions.csv")
        pred_df.to_csv(pred_path)
        
        self.export_data['datasets'][f'{model_name}_predictions'] = pred_path
    
    def save_cv_results(self, model_name, cv_results):
        """Save cross-validation results."""
        if 'grid_search_results' in cv_results:
            gs_results = cv_results['grid_search_results']
            
            # Save all grid search results to CSV
            gs_df = pd.DataFrame(gs_results.get('all_results', []))
            if not gs_df.empty:
                # Expand params dict into columns
                params_df = pd.json_normalize(gs_df['params'])
                gs_df = pd.concat([params_df, gs_df[['mean_rmse', 'std_rmse', 'mean_r2', 'std_r2']]], axis=1)
                
                gs_path = os.path.join(self.cv_dir, f"{model_name}_grid_search.csv")
                gs_df.to_csv(gs_path, index=False)
                
                self.export_data['cv_results'][f'{model_name}_grid_search'] = {
                    'file': gs_path,
                    'best_rmse': float(gs_results.get('best_rmse', 0)),
                    'best_params': gs_results.get('best_params', {})
                }
        
        if 'nested_cv' in cv_results:
            nested = cv_results['nested_cv']
            nested_df = pd.DataFrame(nested.get('fold_details', []))
            
            if not nested_df.empty:
                nested_path = os.path.join(self.cv_dir, f"{model_name}_nested_cv.csv")
                nested_df.to_csv(nested_path, index=False)
                
                self.export_data['cv_results'][f'{model_name}_nested_cv'] = {
                    'file': nested_path,
                    'mean_rmse': float(nested['outer_rmse_mean']),
                    'std_rmse': float(nested['outer_rmse_std']),
                    'mean_r2': float(nested['outer_r2_mean']),
                    'std_r2': float(nested['outer_r2_std'])
                }
    
    def create_residual_plot(self, model_name, y_true, y_pred):
        """Create and save residual analysis plot."""
        from scipy import stats
        
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        residuals = y_true - y_pred
        
        # 1. Predicted vs Actual
        axes[0, 0].scatter(y_true, y_pred, alpha=0.5, s=20)
        axes[0, 0].plot([y_true.min(), y_true.max()], 
                        [y_true.min(), y_true.max()], 
                        'r--', lw=2)
        axes[0, 0].set_xlabel('Actual')
        axes[0, 0].set_ylabel('Predicted')
        axes[0, 0].set_title('Predicted vs Actual')
        axes[0, 0].grid(True, alpha=0.3)
        
        # Add R² annotation
        r2 = r2_score(y_true, y_pred)
        axes[0, 0].text(0.05, 0.95, f'R² = {r2:.3f}', 
                       transform=axes[0, 0].transAxes, 
                       verticalalignment='top',
                       bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        # 2. Residual plot
        axes[0, 1].scatter(y_pred, residuals, alpha=0.5, s=20)
        axes[0, 1].axhline(y=0, color='r', linestyle='--', lw=2)
        axes[0, 1].set_xlabel('Predicted')
        axes[0, 1].set_ylabel('Residuals')
        axes[0, 1].set_title('Residual Plot')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. Residual distribution
        axes[1, 0].hist(residuals, bins=50, edgecolor='black', alpha=0.7)
        axes[1, 0].axvline(x=0, color='r', linestyle='--', lw=2)
        axes[1, 0].set_xlabel('Residuals')
        axes[1, 0].set_ylabel('Frequency')
        axes[1, 0].set_title('Residual Distribution')
        axes[1, 0].grid(True, alpha=0.3)
        
        # Add statistics
        axes[1, 0].text(0.05, 0.95, 
                       f'Mean: {np.mean(residuals):.3f}\nStd: {np.std(residuals):.3f}',
                       transform=axes[1, 0].transAxes, 
                       verticalalignment='top',
                       bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        # 4. Q-Q plot
        stats.probplot(residuals, dist="norm", plot=axes[1, 1])
        axes[1, 1].set_title('Q-Q Plot')
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plot_path = os.path.join(self.plots_dir, f"{model_name}_residual_analysis.png")
        plt.savefig(plot_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        self.export_data['plots'][f'{model_name}_residual_analysis'] = plot_path
        return plot_path
    
    def create_cv_plot(self, model_name, cv_results):
        """Create cross-validation results visualization."""
        if 'grid_search_results' not in cv_results:
            return None
        
        gs_results = cv_results['grid_search_results'].get('all_results', [])
        if not gs_results:
            return None
        
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # Extract data
        combinations = [f"Config {i+1}" for i in range(len(gs_results))]
        rmse_means = [r['mean_rmse'] for r in gs_results]
        rmse_stds = [r['std_rmse'] for r in gs_results]
        r2_means = [r['mean_r2'] for r in gs_results]
        r2_stds = [r['std_r2'] for r in gs_results]
        
        # Plot 1: RMSE comparison
        x = np.arange(len(combinations))
        axes[0].bar(x, rmse_means, yerr=rmse_stds, capsize=5, alpha=0.7)
        axes[0].set_xlabel('Configuration')
        axes[0].set_ylabel('RMSE (°C)')
        axes[0].set_title('Grid Search: RMSE Comparison')
        axes[0].set_xticks(x)
        axes[0].set_xticklabels(combinations, rotation=45, ha='right')
        axes[0].grid(True, alpha=0.3, axis='y')
        
        # Highlight best
        best_idx = np.argmin(rmse_means)
        axes[0].bar(best_idx, rmse_means[best_idx], color='green', alpha=0.9)
        
        # Plot 2: R² comparison
        axes[1].bar(x, r2_means, yerr=r2_stds, capsize=5, alpha=0.7)
        axes[1].set_xlabel('Configuration')
        axes[1].set_ylabel('R²')
        axes[1].set_title('Grid Search: R² Comparison')
        axes[1].set_xticks(x)
        axes[1].set_xticklabels(combinations, rotation=45, ha='right')
        axes[1].grid(True, alpha=0.3, axis='y')
        
        # Highlight best
        best_idx_r2 = np.argmax(r2_means)
        axes[1].bar(best_idx_r2, r2_means[best_idx_r2], color='green', alpha=0.9)
        
        plt.tight_layout()
        plot_path = os.path.join(self.plots_dir, f"{model_name}_cv_comparison.png")
        plt.savefig(plot_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        self.export_data['plots'][f'{model_name}_cv_comparison'] = plot_path
        return plot_path
    
    def create_time_series_plot(self, model_name, dates, y_true, y_pred, title):
        """Create time series comparison plot."""
        fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
        
        # Plot 1: Time series comparison
        axes[0].plot(dates, y_true, label='Actual', alpha=0.7, linewidth=1.5)
        axes[0].plot(dates, y_pred, label='Predicted', alpha=0.7, linewidth=1.5)
        axes[0].set_ylabel('Temperature (°C)')
        axes[0].set_title(title)
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Plot 2: Residuals over time
        residuals = y_true - y_pred
        axes[1].plot(dates, residuals, alpha=0.7, linewidth=1, color='red')
        axes[1].axhline(y=0, color='black', linestyle='--', lw=1)
        axes[1].fill_between(dates, 0, residuals, alpha=0.3, color='red')
        axes[1].set_xlabel('Date')
        axes[1].set_ylabel('Residual (°C)')
        axes[1].set_title('Residuals Over Time')
        axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plot_path = os.path.join(self.plots_dir, f"{model_name}_timeseries.png")
        plt.savefig(plot_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        self.export_data['plots'][f'{model_name}_timeseries'] = plot_path
        return plot_path
    
    def create_feature_importance_plot(self, model_name, feature_names, importances):
        """Create feature importance visualization."""
        # Sort by importance
        indices = np.argsort(importances)[::-1]
        sorted_features = [feature_names[i] for i in indices]
        sorted_importances = importances[indices]
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        bars = ax.barh(range(len(sorted_importances)), sorted_importances, alpha=0.7)
        ax.set_yticks(range(len(sorted_features)))
        ax.set_yticklabels(sorted_features)
        ax.set_xlabel('Importance')
        ax.set_title(f'{model_name}: Feature Importance')
        ax.grid(True, alpha=0.3, axis='x')
        
        # Color bars by importance
        colors = plt.cm.RdYlGn(sorted_importances / sorted_importances.max())
        for bar, color in zip(bars, colors):
            bar.set_color(color)
        
        plt.tight_layout()
        plot_path = os.path.join(self.plots_dir, f"{model_name}_feature_importance.png")
        plt.savefig(plot_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        self.export_data['plots'][f'{model_name}_feature_importance'] = plot_path
        self.export_data['feature_importance'][model_name] = dict(zip(sorted_features, sorted_importances.tolist()))
        
        return plot_path
    
    def _serialize_metrics(self, metrics):
        """Convert metrics to JSON-serializable format."""
        serialized = {}
        for key, value in metrics.items():
            if isinstance(value, (np.integer, np.floating)):
                serialized[key] = float(value)
            elif isinstance(value, dict):
                serialized[key] = self._serialize_metrics(value)
            elif isinstance(value, (list, tuple)):
                serialized[key] = [float(v) if isinstance(v, (np.integer, np.floating)) else v for v in value]
            else:
                serialized[key] = value
        return serialized
    
    def _calculate_residual_stats(self, y_true, y_pred):
        """Calculate comprehensive residual statistics."""
        residuals = y_true - y_pred
        
        return {
            'mean': float(np.mean(residuals)),
            'std': float(np.std(residuals)),
            'min': float(np.min(residuals)),
            'max': float(np.max(residuals)),
            'q25': float(np.percentile(residuals, 25)),
            'median': float(np.median(residuals)),
            'q75': float(np.percentile(residuals, 75)),
            'skewness': float(pd.Series(residuals).skew()),
            'kurtosis': float(pd.Series(residuals).kurtosis())
        }
    
    def export_json(self):
        """Export all data to comprehensive JSON file."""
        json_path = os.path.join(self.output_dir, f"comprehensive_results_{self.city_name.replace(' ', '_')}.json")
        
        with open(json_path, 'w') as f:
            json.dump(self.export_data, f, indent=2, default=str)
        
        print(f"\n{'='*60}")
        print(f"COMPREHENSIVE EXPORT COMPLETED")
        print(f"{'='*60}")
        print(f"Main JSON: {json_path}")
        print(f"Plots directory: {self.plots_dir}")
        print(f"Data directory: {self.data_dir}")
        print(f"CV results directory: {self.cv_dir}")
        print(f"{'='*60}")
        
        return json_path
    
    def create_summary_report(self):
        """Create a human-readable summary report."""
        report_path = os.path.join(self.output_dir, f"summary_report_{self.city_name.replace(' ', '_')}.txt")
        
        with open(report_path, 'w') as f:
            f.write("="*80 + "\n")
            f.write(f"COMPREHENSIVE MODEL ANALYSIS REPORT\n")
            f.write(f"City: {self.city_name}\n")
            f.write(f"Generated: {self.export_data['metadata']['timestamp']}\n")
            f.write("="*80 + "\n\n")
            
            # Metadata
            f.write("DATASET INFORMATION\n")
            f.write("-"*80 + "\n")
            meta = self.export_data['metadata']
            f.write(f"Number of samples: {meta['n_samples']}\n")
            f.write(f"Date range: {meta['date_range']['start']} to {meta['date_range']['end']}\n")
            f.write(f"Number of features: {len(meta['features'])}\n")
            f.write(f"Features: {', '.join(meta['features'])}\n\n")
            
            # Model results
            f.write("MODEL PERFORMANCE SUMMARY\n")
            f.write("-"*80 + "\n")
            for model_name, model_data in self.export_data['models'].items():
                f.write(f"\n{model_name}:\n")
                metrics = model_data['metrics']
                if 'train_rmse' in metrics:
                    f.write(f"  Train RMSE: {metrics['train_rmse']:.3f}°C\n")
                if 'test_rmse' in metrics:
                    f.write(f"  Test RMSE: {metrics['test_rmse']:.3f}°C\n")
                if 'train_r2' in metrics:
                    f.write(f"  Train R²: {metrics['train_r2']:.3f}\n")
                if 'test_r2' in metrics:
                    f.write(f"  Test R²: {metrics['test_r2']:.3f}\n")
                if 'overfitting_gap' in metrics:
                    f.write(f"  Overfitting gap: {metrics['overfitting_gap']:.3f}\n")
                
                if 'best_params' in model_data:
                    f.write(f"  Best parameters:\n")
                    for param, value in model_data['best_params'].items():
                        f.write(f"    {param}: {value}\n")
            
            # CV results
            if self.export_data['cv_results']:
                f.write("\n\nCROSS-VALIDATION RESULTS\n")
                f.write("-"*80 + "\n")
                for cv_name, cv_data in self.export_data['cv_results'].items():
                    f.write(f"\n{cv_name}:\n")
                    if 'mean_rmse' in cv_data:
                        f.write(f"  Mean RMSE: {cv_data['mean_rmse']:.3f} ± {cv_data.get('std_rmse', 0):.3f}°C\n")
                        f.write(f"  Mean R²: {cv_data.get('mean_r2', 0):.3f} ± {cv_data.get('std_r2', 0):.3f}\n")
            
            # Feature importance
            if self.export_data['feature_importance']:
                f.write("\n\nFEATURE IMPORTANCE\n")
                f.write("-"*80 + "\n")
                for model_name, importance_dict in self.export_data['feature_importance'].items():
                    f.write(f"\n{model_name}:\n")
                    for feature, importance in importance_dict.items():
                        f.write(f"  {feature}: {importance:.4f}\n")
            
            # Generated files
            f.write("\n\nGENERATED FILES\n")
            f.write("-"*80 + "\n")
            f.write(f"\nPlots ({len(self.export_data['plots'])}):\n")
            for plot_name, plot_path in self.export_data['plots'].items():
                f.write(f"  {plot_name}: {plot_path}\n")
            
            f.write(f"\nDatasets ({len(self.export_data['datasets'])}):\n")
            for ds_name, ds_path in self.export_data['datasets'].items():
                f.write(f"  {ds_name}: {ds_path}\n")
        
        print(f"Summary report: {report_path}")
        return report_path




class RidgeDownscaler:
    """Ridge Regression with exhaustive 50-combination grid search."""
    
    def __init__(self):
        self.model = None
        self.scaler = None
        self.best_params = {}
        self.grid_search_results = {}
    
    def get_param_grid(self):
        """Generate 50 diverse parameter combinations for Ridge."""
        params_list = [
            # Very low alpha (minimal regularization)
            {'alpha': 0.001, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 0.01, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 0.001, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 0.01, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-4},
            
            # Low alpha
            {'alpha': 0.1, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 0.1, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 0.1, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 0.1, 'solver': 'lsqr', 'fit_intercept': True, 'tol': 1e-4},
            
            # Medium-low alpha
            {'alpha': 0.5, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 0.5, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 0.5, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 0.5, 'solver': 'sag', 'fit_intercept': True, 'tol': 1e-4},
            
            # Medium alpha
            {'alpha': 1.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 1.0, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 1.0, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 1.0, 'solver': 'lsqr', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 1.0, 'solver': 'saga', 'fit_intercept': True, 'tol': 1e-4},
            
            # Medium-high alpha
            {'alpha': 2.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 2.0, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 2.0, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 2.0, 'solver': 'sag', 'fit_intercept': True, 'tol': 1e-4},
            
            # High alpha
            {'alpha': 5.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 5.0, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 5.0, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 5.0, 'solver': 'saga', 'fit_intercept': True, 'tol': 1e-4},
            
            # Higher alpha
            {'alpha': 10.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 10.0, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 10.0, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 10.0, 'solver': 'lsqr', 'fit_intercept': True, 'tol': 1e-4},
            
            # Very high alpha
            {'alpha': 20.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 20.0, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 20.0, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 50.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            
            # Ultra-high alpha
            {'alpha': 50.0, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 100.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 100.0, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 200.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4},
            
            # Extreme alpha
            {'alpha': 500.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 1000.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-3},
            
            # No intercept variations
            {'alpha': 1.0, 'solver': 'auto', 'fit_intercept': False, 'tol': 1e-4},
            {'alpha': 5.0, 'solver': 'svd', 'fit_intercept': False, 'tol': 1e-4},
            {'alpha': 10.0, 'solver': 'cholesky', 'fit_intercept': False, 'tol': 1e-4},
            
            # Tolerance variations
            {'alpha': 1.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-5},
            {'alpha': 5.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-5},
            {'alpha': 1.0, 'solver': 'svd', 'fit_intercept': True, 'tol': 1e-2},
            {'alpha': 5.0, 'solver': 'cholesky', 'fit_intercept': True, 'tol': 1e-2},
            
            # Mixed solver variations
            {'alpha': 2.0, 'solver': 'sparse_cg', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 5.0, 'solver': 'sparse_cg', 'fit_intercept': True, 'tol': 1e-4},
            {'alpha': 10.0, 'solver': 'sparse_cg', 'fit_intercept': True, 'tol': 1e-3},
            {'alpha': 1.0, 'solver': 'sag', 'fit_intercept': True, 'tol': 1e-3},
        ]
        
        return params_list
    
    def grid_search_cv(self, X, y, n_splits=5):
        """Perform exhaustive 50-combination grid search for Ridge."""
        from sklearn.model_selection import TimeSeriesSplit
        
        print(f"  EXHAUSTIVE GRID SEARCH: Testing 50 parameter combinations...")
        print(f"  Using {n_splits}-fold Time Series CV\n")
        
        params_list = self.get_param_grid()
        
        tscv = TimeSeriesSplit(n_splits=n_splits)
        best_score = float('inf')
        best_params = None
        all_results = []
        
        for idx, params in enumerate(params_list, 1):
            if idx % 10 == 1:
                print(f"  Progress: {idx}/50 combinations tested...")
            
            fold_scores = []
            fold_r2 = []
            
            for fold, (train_idx, val_idx) in enumerate(tscv.split(X), 1):
                X_train_fold = X.iloc[train_idx]
                y_train_fold = y.iloc[train_idx]
                X_val_fold = X.iloc[val_idx]
                y_val_fold = y.iloc[val_idx]
                
                scaler = StandardScaler()
                X_train_scaled = scaler.fit_transform(X_train_fold)
                X_val_scaled = scaler.transform(X_val_fold)
                
                model = Ridge(**params, random_state=Config.RANDOM_STATE)
                model.fit(X_train_scaled, y_train_fold)
                
                y_pred = model.predict(X_val_scaled)
                rmse = np.sqrt(mean_squared_error(y_val_fold, y_pred))
                r2 = r2_score(y_val_fold, y_pred)
                
                fold_scores.append(rmse)
                fold_r2.append(r2)
            
            mean_rmse = np.mean(fold_scores)
            std_rmse = np.std(fold_scores)
            mean_r2 = np.mean(fold_r2)
            std_r2 = np.std(fold_r2)
            
            all_results.append({
                'config_id': idx,
                'params': params,
                'mean_rmse': mean_rmse,
                'std_rmse': std_rmse,
                'mean_r2': mean_r2,
                'std_r2': std_r2
            })
            
            if mean_rmse < best_score:
                best_score = mean_rmse
                best_params = params
                print(f"    Config #{idx}: NEW BEST RMSE = {best_score:.4f}°C (R²={mean_r2:.4f})")
        
        self.best_params = best_params
        self.grid_search_results = {
            'best_rmse': best_score,
            'best_params': best_params,
            'all_results': all_results
        }
        
        print(f"\n  ✓ GRID SEARCH COMPLETE!")
        print(f"  BEST PARAMETERS:")
        for param, value in best_params.items():
            print(f"    {param}: {value}")
        print(f"  Best CV RMSE: {best_score:.4f}°C\n")
        
        return best_params
    
    def train(self, X_train, y_train, params=None):
        """Train Ridge regression."""
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        
        if params is None:
            params = self.best_params if self.best_params else {
                'alpha': 1.0, 'solver': 'auto', 'fit_intercept': True, 'tol': 1e-4
            }
        
        self.model = Ridge(**params, random_state=Config.RANDOM_STATE)
        self.model.fit(X_train_scaled, y_train)
        return self.model
    
    def predict(self, X):
        """Make predictions."""
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)
    
    def downscale(self, df, era5_col, station_col, feature_cols):
        """Downscale ERA5 to station scale with exhaustive grid search."""
        print(f"\n{'='*70}")
        print(f"RIDGE DOWNSCALING: {era5_col} -> {station_col}")
        print(f"{'='*70}")
        
        df_sub = df[feature_cols + [era5_col, station_col]].dropna()
        if len(df_sub) < 50:
            print(f"  Not enough data: {len(df_sub)} samples")
            return None, {}
        
        X = df_sub[feature_cols + [era5_col]]
        y = df_sub[station_col]
        
        print(f"Dataset: {len(X)} samples, {len(feature_cols)+1} features")
        
        # Grid search
        final_params = self.grid_search_cv(X, y, n_splits=5)
        
        # Train-test split
        split_idx = int(len(X) * (1 - Config.TEST_SIZE))
        X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
        y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
        
        # Train model
        self.train(X_train, y_train, params=final_params)
        
        # Predict
        y_pred_train = self.predict(X_train)
        y_pred_test = self.predict(X_test)
        
        # Calculate metrics
        era5_rmse = np.sqrt(mean_squared_error(y_test, X_test[era5_col]))
        model_rmse = np.sqrt(mean_squared_error(y_test, y_pred_test))
        improvement = ((era5_rmse - model_rmse) / era5_rmse * 100) if era5_rmse > 0 else 0
        
        metrics = {
            'era5_rmse': era5_rmse,
            'model_rmse': model_rmse,
            'improvement_pct': improvement,
            'train_r2': r2_score(y_train, y_pred_train),
            'test_r2': r2_score(y_test, y_pred_test),
            'train_rmse': np.sqrt(mean_squared_error(y_train, y_pred_train)),
            'test_rmse': model_rmse,
            'best_params': final_params,
            'grid_search_results': self.grid_search_results,
            'n_combinations_tested': 50,
            'coefficients': dict(zip(X.columns, self.model.coef_))
        }
        
        # Apply to full dataset
        X_full = df[feature_cols + [era5_col]].fillna(method='ffill')
        downscaled = self.predict(X_full)
        downscaled_series = pd.Series(downscaled, index=df.index, name=f'{station_col}_downscaled')
        
        print(f"\nFINAL PERFORMANCE:")
        print(f"  ERA5 RMSE: {era5_rmse:.3f}°C")
        print(f"  Model RMSE: {model_rmse:.3f}°C (improvement: {improvement:.1f}%)")
        print(f"  Test R²: {metrics['test_r2']:.3f}")
        print(f"{'='*70}\n")
        
        return downscaled_series, metrics


# ============================================================
# SIMPLE EVALUATION
# ============================================================
class SimpleEvaluator:
    """Simple model evaluation."""
    
    def __init__(self, output_dir):
        self.output_dir = output_dir
        self.results = {}
    
    def evaluate_model(self, y_true, y_pred, name, model_type):
        """Evaluate a single model."""
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        mae = mean_absolute_error(y_true, y_pred)
        r2 = r2_score(y_true, y_pred)
        
        results = {
            'rmse': rmse,
            'mae': mae,
            'r2': r2,
            'n_samples': len(y_true)
        }
        
        self.results[f"{model_type}_{name}"] = results
        print(f"  {name}: RMSE={rmse:.3f}, MAE={mae:.3f}, R²={r2:.3f}")
        return results
    
    def save_results(self, filename="model_results.json"):
        """Save all results."""
        path = os.path.join(self.output_dir, filename)
        with open(path, 'w') as f:
            json.dump(self.results, f, indent=2, default=str)
        print(f"Results saved to: {path}")
























































class QuantileRegressionModel:
    """
    State-of-the-art Quantile Regression for uncertainty quantification.
    Provides prediction intervals (e.g., 10th, 50th, 90th percentiles).
    """
    
    def __init__(self):
        self.models = {}  # Dictionary to store models for different quantiles
        self.scaler = None
        self.quantiles = [0.1, 0.25, 0.5, 0.75, 0.9]  # Prediction intervals
        self.best_params = {}
        self.grid_search_results = {}
    
    def get_param_grid(self):
        """Generate 40 parameter combinations for Quantile XGBoost."""
        params_list = [
            # Conservative
            {'n_estimators': 50, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 75, 'max_depth': 2, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'min_child_weight': 5},
            {'n_estimators': 60, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.7, 'min_child_weight': 7},
            {'n_estimators': 50, 'max_depth': 2, 'learning_rate': 0.05, 'subsample': 0.7, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            
            # Moderate
            {'n_estimators': 100, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 3},
            {'n_estimators': 80, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.7, 'min_child_weight': 5},
            {'n_estimators': 100, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 75, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.7, 'colsample_bytree': 0.8, 'min_child_weight': 3},
            
            # Balanced
            {'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 3},
            {'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.7, 'min_child_weight': 5},
            {'n_estimators': 90, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.9, 'colsample_bytree': 0.8, 'min_child_weight': 3},
            
            # Higher learning rate
            {'n_estimators': 75, 'max_depth': 3, 'learning_rate': 0.07, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 60, 'max_depth': 4, 'learning_rate': 0.07, 'subsample': 0.8, 'colsample_bytree': 0.7, 'min_child_weight': 3},
            {'n_estimators': 80, 'max_depth': 3, 'learning_rate': 0.07, 'subsample': 0.7, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 50, 'max_depth': 4, 'learning_rate': 0.1, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            
            # Deeper trees
            {'n_estimators': 80, 'max_depth': 5, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.7, 'min_child_weight': 5},
            {'n_estimators': 100, 'max_depth': 5, 'learning_rate': 0.03, 'subsample': 0.7, 'colsample_bytree': 0.7, 'min_child_weight': 7},
            {'n_estimators': 75, 'max_depth': 5, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 60, 'max_depth': 5, 'learning_rate': 0.07, 'subsample': 0.8, 'colsample_bytree': 0.7, 'min_child_weight': 3},
            
            # More trees
            {'n_estimators': 150, 'max_depth': 3, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 120, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 3},
            {'n_estimators': 150, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.7, 'colsample_bytree': 0.7, 'min_child_weight': 5},
            {'n_estimators': 100, 'max_depth': 5, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            
            # Low subsample
            {'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.6, 'colsample_bytree': 0.7, 'min_child_weight': 5},
            {'n_estimators': 80, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.6, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.03, 'subsample': 0.6, 'colsample_bytree': 0.7, 'min_child_weight': 7},
            {'n_estimators': 75, 'max_depth': 5, 'learning_rate': 0.05, 'subsample': 0.6, 'colsample_bytree': 0.7, 'min_child_weight': 5},
            
            # High subsample
            {'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.9, 'colsample_bytree': 0.9, 'min_child_weight': 3},
            {'n_estimators': 80, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.9, 'colsample_bytree': 0.8, 'min_child_weight': 5},
            {'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.03, 'subsample': 0.9, 'colsample_bytree': 0.8, 'min_child_weight': 3},
            {'n_estimators': 120, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.9, 'colsample_bytree': 0.9, 'min_child_weight': 5},
            
            # Feature sampling variations
            {'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.6, 'min_child_weight': 5},
            {'n_estimators': 80, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.9, 'min_child_weight': 5},
            {'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.03, 'subsample': 0.8, 'colsample_bytree': 0.6, 'min_child_weight': 5},
            {'n_estimators': 90, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.9, 'min_child_weight': 3},
            
            # Mixed configurations
            {'n_estimators': 110, 'max_depth': 4, 'learning_rate': 0.04, 'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 4},
            {'n_estimators': 90, 'max_depth': 3, 'learning_rate': 0.06, 'subsample': 0.75, 'colsample_bytree': 0.75, 'min_child_weight': 5},
            {'n_estimators': 85, 'max_depth': 4, 'learning_rate': 0.05, 'subsample': 0.85, 'colsample_bytree': 0.75, 'min_child_weight': 4},
            {'n_estimators': 95, 'max_depth': 3, 'learning_rate': 0.05, 'subsample': 0.8, 'colsample_bytree': 0.85, 'min_child_weight': 4},
        ]
        
        return params_list
    
    def grid_search_cv(self, X, y, n_splits=5):
        """Grid search for median quantile (0.5) to find best base parameters."""
        from sklearn.model_selection import TimeSeriesSplit
        
        print(f"  QUANTILE MODEL: Grid search on median (q=0.5)...")
        print(f"  Testing 40 parameter combinations with {n_splits}-fold CV\n")
        
        params_list = self.get_param_grid()
        
        tscv = TimeSeriesSplit(n_splits=n_splits)
        best_score = float('inf')
        best_params = None
        all_results = []
        
        for idx, params in enumerate(params_list, 1):
            if idx % 10 == 1:
                print(f"  Progress: {idx}/40 combinations tested...")
            
            fold_scores = []
            
            for fold, (train_idx, val_idx) in enumerate(tscv.split(X), 1):
                X_train_fold = X.iloc[train_idx]
                y_train_fold = y.iloc[train_idx]
                X_val_fold = X.iloc[val_idx]
                y_val_fold = y.iloc[val_idx]
                
                scaler = StandardScaler()
                X_train_scaled = scaler.fit_transform(X_train_fold)
                X_val_scaled = scaler.transform(X_val_fold)
                
                # Train quantile model for median
                model = xgb.XGBRegressor(
                    **params,
                    objective='reg:quantileerror',
                    quantile_alpha=0.5,
                    random_state=Config.RANDOM_STATE,
                    n_jobs=-1
                )
                
                model.fit(X_train_scaled, y_train_fold, verbose=False)
                
                y_pred = model.predict(X_val_scaled)
                rmse = np.sqrt(mean_squared_error(y_val_fold, y_pred))
                
                fold_scores.append(rmse)
            
            mean_rmse = np.mean(fold_scores)
            std_rmse = np.std(fold_scores)
            
            all_results.append({
                'config_id': idx,
                'params': params,
                'mean_rmse': mean_rmse,
                'std_rmse': std_rmse
            })
            
            if mean_rmse < best_score:
                best_score = mean_rmse
                best_params = params
                print(f"    Config #{idx}: NEW BEST RMSE = {best_score:.4f}°C")
        
        self.best_params = best_params
        self.grid_search_results = {
            'best_rmse': best_score,
            'best_params': best_params,
            'all_results': all_results
        }
        
        print(f"\n  ✓ GRID SEARCH COMPLETE!")
        print(f"  BEST PARAMETERS (for all quantiles):")
        for param, value in best_params.items():
            print(f"    {param}: {value}")
        print(f"  Best median RMSE: {best_score:.4f}°C\n")
        
        return best_params
    
    def train(self, X_train, y_train, params=None):
        """Train quantile models for all specified quantiles."""
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        
        if params is None:
            params = self.best_params if self.best_params else {
                'n_estimators': 100, 'max_depth': 4, 'learning_rate': 0.05,
                'subsample': 0.8, 'colsample_bytree': 0.8, 'min_child_weight': 3
            }
        
        print(f"  Training models for quantiles: {self.quantiles}")
        
        for q in self.quantiles:
            print(f"    Training quantile {q:.2f}...", end='')
            
            model = xgb.XGBRegressor(
                **params,
                objective='reg:quantileerror',
                quantile_alpha=q,
                random_state=Config.RANDOM_STATE,
                n_jobs=-1
            )
            
            model.fit(X_train_scaled, y_train, verbose=False)
            self.models[q] = model
            print(" ✓")
        
        return self.models
    
    def predict(self, X):
        """Predict all quantiles for given features."""
        X_scaled = self.scaler.transform(X)
        
        predictions = {}
        for q in self.quantiles:
            predictions[f'q{int(q*100)}'] = self.models[q].predict(X_scaled)
        
        return predictions
    
    def calculate_interval_metrics(self, y_true, predictions):
        """Calculate prediction interval coverage and width."""
        # 80% prediction interval (10th to 90th percentile)
        lower_80 = predictions['q10']
        upper_80 = predictions['q90']
        coverage_80 = np.mean((y_true >= lower_80) & (y_true <= upper_80))
        width_80 = np.mean(upper_80 - lower_80)
        
        # 50% prediction interval (25th to 75th percentile)
        lower_50 = predictions['q25']
        upper_50 = predictions['q75']
        coverage_50 = np.mean((y_true >= lower_50) & (y_true <= upper_50))
        width_50 = np.mean(upper_50 - lower_50)
        
        return {
            'coverage_80': coverage_80,
            'width_80': width_80,
            'coverage_50': coverage_50,
            'width_50': width_50
        }
    
    def run(self, df, target_col, feature_cols, prediction_name='quantile_prediction'):
        """Run complete quantile regression pipeline."""
        print(f"\n{'='*70}")
        print(f"QUANTILE REGRESSION: {target_col}")
        print(f"Uncertainty quantification with prediction intervals")
        print(f"{'='*70}")
        
        # Prepare data
        df_sub = df[feature_cols + [target_col]].dropna()
        if len(df_sub) < 50:
            print(f"  Not enough data: {len(df_sub)} samples")
            return None, {}
        
        X = df_sub[feature_cols]
        y = df_sub[target_col]
        
        print(f"Dataset: {len(X)} samples, {len(feature_cols)} features")
        
        # Grid search
        final_params = self.grid_search_cv(X, y, n_splits=5)
        
        # Train-test split
        split_idx = int(len(X) * (1 - Config.TEST_SIZE))
        X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
        y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
        
        print(f"\nTraining all quantile models on {len(X_train)} samples...")
        self.train(X_train, y_train, params=final_params)
        
        # Predictions
        train_preds = self.predict(X_train)
        test_preds = self.predict(X_test)
        
        # Metrics (using median as point estimate)
        train_rmse = np.sqrt(mean_squared_error(y_train, train_preds['q50']))
        test_rmse = np.sqrt(mean_squared_error(y_test, test_preds['q50']))
        train_r2 = r2_score(y_train, train_preds['q50'])
        test_r2 = r2_score(y_test, test_preds['q50'])
        
        # Interval metrics
        train_intervals = self.calculate_interval_metrics(y_train.values, train_preds)
        test_intervals = self.calculate_interval_metrics(y_test.values, test_preds)
        
        metrics = {
            'train_rmse': train_rmse,
            'test_rmse': test_rmse,
            'train_r2': train_r2,
            'test_r2': test_r2,
            'train_mae': mean_absolute_error(y_train, train_preds['q50']),
            'test_mae': mean_absolute_error(y_test, test_preds['q50']),
            'train_interval_metrics': train_intervals,
            'test_interval_metrics': test_intervals,
            'best_params': final_params,
            'grid_search_results': self.grid_search_results,
            'n_combinations_tested': 40,
            'quantiles': self.quantiles
        }
        
        # Apply to full dataset
        X_full = df[feature_cols].fillna(method='ffill')
        full_preds = self.predict(X_full)
        
        # Create dataframe with all quantiles
        result_df = pd.DataFrame(full_preds, index=df.index)
        
        print(f"\nFINAL PERFORMANCE (Median Quantile):")
        print(f"  Train: RMSE={train_rmse:.3f}°C, R²={train_r2:.3f}")
        print(f"  Test:  RMSE={test_rmse:.3f}°C, R²={test_r2:.3f}")
        print(f"\nPREDICTION INTERVALS:")
        print(f"  80% interval coverage (test): {test_intervals['coverage_80']:.1%} (target: 80%)")
        print(f"  80% interval width (test): {test_intervals['width_80']:.2f}°C")
        print(f"  50% interval coverage (test): {test_intervals['coverage_50']:.1%} (target: 50%)")
        print(f"  50% interval width (test): {test_intervals['width_50']:.2f}°C")
        print(f"{'='*70}\n")
        
        return result_df, metrics


# ============================================================
# MAIN PIPELINE
# ============================================================
class SimpleModelingPipeline:
    """Simplified 3-model pipeline with exhaustive grid search."""
    
    def __init__(self, city_name):
        self.city = city_name
        self.data_loader = DataLoader(city_name)
        self.df = None
        self.metrics = {}
    
    def run(self):
        """Run the complete pipeline."""
        print(f"\n{'='*70}")
        print(f"EXHAUSTIVE GRID SEARCH PIPELINE")
        print(f"City: {self.city}")
        print(f"48-50 combinations per model")
        print(f"{'='*70}")
        
        # Step 1: Load data
        print("\n[1/4] Loading data...")
        self.df, self.metrics = self.data_loader.load_data()
        
        # Step 2: Feature engineering
        print("\n[2/4] Creating features...")
        self.df = self.data_loader.create_basic_features(self.df)
        
        # Save data
        output_path = os.path.join(Config.OUTPUT_DIR, f"prepared_data_{self.city.replace(' ', '_')}.csv")
        self.df.to_csv(output_path)
        print(f"  Data saved to: {output_path}")
        
        # Step 3: Run models
        print("\n[3/4] Running 3 models with exhaustive grid search...")
        
        # Define common features
        common_features = ['day_sin', 'day_cos', 'month', 'FG_ms_city_mean', 'PP_hPa_city_mean']
        available_features = [f for f in common_features if f in self.df.columns]
        
        # Initialize evaluator
        evaluator = SimpleEvaluator(Config.OUTPUT_DIR)
        all_predictions = {}
        all_metrics = {}
        
        # Model 1: XGBoost Bias Correction
        if 'ERA5_t2m_max_C' in self.df.columns and 'TX_C_city_mean' in self.df.columns:
            bias_corrector = XGBoostBiasCorrector()
            corrected_series, bias_metrics = bias_corrector.correct(
                self.df, 'ERA5_t2m_max_C', 'TX_C_city_mean', available_features
            )
            if corrected_series is not None:
                self.df['TX_corrected'] = corrected_series
                all_predictions['bias_correction'] = corrected_series
                all_metrics['XGBoost_Bias_Correction'] = bias_metrics
        
        # Model 2: Random Forest UHI
        uhi_predictor = RandomForestUHIPredictor()
        uhi_target = uhi_predictor.create_uhi_target(self.df, self.metrics)
        self.df['UHI_target'] = uhi_target
        
        uhi_features = ['day_sin', 'day_cos', 'FG_ms_city_mean', 'NDVI_city']
        uhi_features = [f for f in uhi_features if f in self.df.columns]
        
        uhi_predicted, uhi_metrics = uhi_predictor.run(self.df, uhi_target, uhi_features)
        if uhi_predicted is not None:
            self.df['UHI_predicted'] = uhi_predicted
            all_predictions['uhi'] = uhi_predicted
            all_metrics['RandomForest_UHI'] = uhi_metrics
        
        # Model 3: Ridge Downscaling
        if 'ERA5_t2m_min_C' in self.df.columns and 'TN_C_city_mean' in self.df.columns:
            downscaler = RidgeDownscaler()
            downscaled_series, downscale_metrics = downscaler.downscale(
                self.df, 'ERA5_t2m_min_C', 'TN_C_city_mean', available_features
            )
            if downscaled_series is not None:
                self.df['TN_downscaled'] = downscaled_series
                all_predictions['downscaling'] = downscaled_series
                all_metrics['Ridge_Downscaling'] = downscale_metrics
        




        
        # Model 4: Quantile Regression (NEW!)
        if 'TX_C_city_mean' in self.df.columns:
            quantile_model = QuantileRegressionModel()
            quantile_features = [f for f in available_features if f in self.df.columns]
            
            quantile_results, quantile_metrics = quantile_model.run(
                self.df, 'TX_C_city_mean', quantile_features, 'TX_quantiles'
            )
            
            if quantile_results is not None:
                # Add quantile predictions to dataframe
                for col in quantile_results.columns:
                    self.df[f'TX_{col}'] = quantile_results[col]
                
                all_predictions['quantile_median'] = quantile_results['q50']
                all_metrics['Quantile_Regression'] = quantile_metrics

        # Step 4: Save results
        print("\n[4/4] Saving exhaustive results...")
        
        # Save predictions
        predictions_df = pd.DataFrame(all_predictions)
        predictions_path = os.path.join(Config.OUTPUT_DIR, f"predictions_{self.city.replace(' ', '_')}.csv")
        predictions_df.to_csv(predictions_path)
        print(f"  Predictions saved to: {predictions_path}")
        
        # Save detailed metrics with all grid search results
        metrics_path = os.path.join(Config.OUTPUT_DIR, f"exhaustive_grid_search_results_{self.city.replace(' ', '_')}.json")
        with open(metrics_path, 'w') as f:
            json.dump(all_metrics, f, indent=2, default=str)
        print(f"  Grid search results saved to: {metrics_path}")
        
        print(f"\n{'='*70}")
        print("EXHAUSTIVE GRID SEARCH COMPLETED!")
        print(f"Total combinations tested: 48 + 48 + 50 = 146")
        print(f"Results in: {Config.OUTPUT_DIR}")
        print(f"{'='*70}")
        
        return self.df, all_metrics


# ============================================================
# MAIN EXECUTION
# ============================================================
def main():
    """Main execution."""
    print("\n" + "="*70)
    print("GENHACK WEEK 4 - EXHAUSTIVE GRID SEARCH SYSTEM")
    print("48-50 combinations per model")
    print("="*70)
    
    # Get city name
    if len(sys.argv) > 1:
        city_name = sys.argv[1]
    else:
        outputs_dir = os.path.join(Config.BASE_DIR, "outputs")
        if os.path.exists(outputs_dir):
            feature_files = [f for f in os.listdir(outputs_dir) if f.startswith("features_")]
            if feature_files:
                city_name = feature_files[0].replace("features_", "").replace(".csv", "").replace("_", " ")
                print(f"Detected city: {city_name}")
            else:
                city_name = "Berlin"
        else:
            city_name = "Berlin"
    
    try:
        # Run pipeline
        pipeline = SimpleModelingPipeline(city_name)
        results_df, metrics = pipeline.run()
        
        # Print summary
        print("\nFINAL SUMMARY:")
        print("-" * 70)
        for model_name, model_metrics in metrics.items():
            print(f"\n{model_name}:")
            if 'best_params' in model_metrics:
                print(f"  Best parameters found from {model_metrics.get('n_combinations_tested', 'N/A')} combinations")
            if 'test_rmse' in model_metrics:
                print(f"  Test RMSE: {model_metrics['test_rmse']:.3f}°C")
            if 'test_r2' in model_metrics:
                print(f"  Test R²: {model_metrics['test_r2']:.3f}")
        
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

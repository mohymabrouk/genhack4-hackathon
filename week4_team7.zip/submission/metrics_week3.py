# -*- coding: utf-8 -*-
"""
GenHack Week 3 – FINAL Robust Pipeline with Progress Bars
=========================================================
- BASE_DIR = C:\\Users\\userpc\\Desktop\\main\\ALL_EXTRACTED\\main
- Reads: gadm_410_europe.gpkg derived-era5-land-daily-statistics
         sentinel2_ndvi ECA_blend_tx, ECA_blend_tn, ECA_blend_tg,
         ECA_blend_rr, ECA_blend_pp, ECA_blend_fg
- Station selection:
  * Uses all TX files in ECA_blend_tx
  * Tries to match with stations.txt for coordinates
  * If no match → still uses TX filenames (no distances, no UHI)
- Logging:
  * errors_<City>.txt is CLEARED at the start of each run
  * All errors + some info messages are appended there
  * Console shows progress bars and high-level info
Outputs:
- outputs/features_<City>.csv
- outputs/metrics_<City>.json
- plus copies in BASE_DIR: features_<City>.csv, metrics_<City>.json

Precipitation units: 0.1mm
units cumulative sum over 6years
"""

import os
import sys
import json
import warnings
import traceback
from typing import Optional, Tuple, Dict, List
import numpy as np
import pandas as pd
import geopandas as gpd
import xarray as xr
import rioxarray  # noqa
from shapely.geometry import Point
from tqdm import tqdm  # progress bars

try:
    import rasterio
except ImportError:
    rasterio = None
try:
    from scipy import stats
except ImportError:
    stats = None
try:
    from sklearn.linear_model import LinearRegression
except ImportError:
    LinearRegression = None

# ============================================================
# FIX WINDOWS CONSOLE ENCODING ISSUES
# ============================================================
if sys.platform == 'win32':
    try:
        # Force UTF-8 encoding for stdout/stderr on Windows
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        # Python < 3.7 fallback
        import codecs
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
        sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# ============================================================
# CONFIG – YOUR REAL PATH
# ============================================================
BASE_DIR = r"C:\Users\userpc\Desktop\main\ALL_EXTRACTED\main"
PATH_GADM = os.path.join(BASE_DIR, "gadm_410_europe.gpkg")
PATH_ERA5_DIR = os.path.join(BASE_DIR, "derived-era5-land-daily-statistics")
PATH_NDVI_DIR = os.path.join(BASE_DIR, "sentinel2_ndvi")
PATH_ECAD_TX_DIR = os.path.join(BASE_DIR, "ECA_blend_tx")
PATH_STATIONS_META = os.path.join(PATH_ECAD_TX_DIR, "stations.txt")
PATH_ECAD_TN_DIR = os.path.join(BASE_DIR, "ECA_blend_tn")
#PATH_ECAD_TG_DIR = os.path.join(BASE_DIR, "ECA_blend_tg") ignore this please
PATH_ECAD_RR_DIR = os.path.join(BASE_DIR, "ECA_blend_rr")
PATH_ECAD_PP_DIR = os.path.join(BASE_DIR, "ECA_blend_pp")
PATH_ECAD_FG_DIR = os.path.join(BASE_DIR, "ECA_blend_fg")

# ERRORS_LOG will be set dynamically per city
ERRORS_LOG = None

ECA_VAR_CONFIG = {
    "TX": {"dir": PATH_ECAD_TX_DIR, "scale": 0.1},  # 0.1 °C
    "TN": {"dir": PATH_ECAD_TN_DIR, "scale": 0.1},
    "RR": {"dir": PATH_ECAD_RR_DIR, "scale": 1},  # 0.1 mm
    "PP": {"dir": PATH_ECAD_PP_DIR, "scale": 0.1},  # 0.1 hPa
    "FG": {"dir": PATH_ECAD_FG_DIR, "scale": 0.1},  # 0.1 m/s
}

ERA5_FILE_PATTERNS = {
    "t2m_max": "{year}_2m_temperature_daily_maximum.nc",  # CHANGE NAME
    "t2m_min": "{year}_2m_temperature_daily_minimum.nc",  # ADD THIS LINE
    "tp": "{year}_total_precipitation_daily_mean.nc",
    "u10": "{year}_10m_u_component_of_wind_daily_mean.nc",
    "v10": "{year}_10m_v_component_of_wind_daily_mean.nc",
}


ERA5_VAR_NAMES = {
    "t2m_max": "t2m",  # CHANGE TO t2m_max
    "t2m_min": "t2m",  # ADD THIS LINE
    "tp": "tp",
    "u10": "u10",
    "v10": "v10",
}

# ============================================================
# SAFE PRINT FUNCTIONS (UNICODE-SAFE)
# ============================================================
def safe_print(msg: str):
    """Print with fallback for Unicode errors on Windows console."""
    try:
        print(msg)
    except UnicodeEncodeError:
        # Fallback: replace unprintable chars with ASCII equivalents
        print(msg.encode('ascii', errors='replace').decode('ascii'))

# ============================================================
# ERROR LOGGING
# ============================================================
def init_error_log(city_name: str):
    """CLEAR errors_<city>.txt at the beginning of each run."""
    global ERRORS_LOG
    try:
        cname = city_name.replace(" ", "_")
        ERRORS_LOG = os.path.join(BASE_DIR, f"errors_{cname}.txt")
        with open(ERRORS_LOG, "w", encoding="utf-8") as f:
            f.write(f"=== NEW RUN FOR {city_name} ===\n")
    except Exception as e:
        safe_print(f"WARNING: Could not initialize error log: {e}")
        ERRORS_LOG = None

def log_error(msg: str):
    """Append a message to errors_<city>.txt."""
    if ERRORS_LOG is None:
        safe_print(f"ERROR LOG: {msg}")
        return
    try:
        with open(ERRORS_LOG, "a", encoding="utf-8") as f:
            f.write(msg.rstrip() + "\n")
    except Exception as e:
        safe_print(f"LOGGING FAILED: {msg} (Error: {e})")

def exception_hook(exc_type, exc_value, exc_traceback):
    """Global hook: log ANY uncaught exception to errors.txt."""
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    text = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    log_error("UNCAUGHT EXCEPTION:\n" + text)
    safe_print("An error occurred. See errors_<city>.txt for details.")

sys.excepthook = exception_hook

# ============================================================
# UTIL
# ============================================================
def dms_to_deg(s):
    """Convert D:M:S (with commas or colons) to decimal degrees."""
    try:
        s = s.strip().replace("+", "").replace("−", "-")
        s = s.replace(",", ":")
        parts = s.split(":")
        if len(parts) == 3:
            d, m, sec = parts
        elif len(parts) == 2:
            d, m = parts
            sec = 0
        else:
            return np.nan
        d = float(d)
        m = float(m)
        sec = float(sec)
        return d + m / 60 + sec / 3600
    except Exception:
        return np.nan

def haversine(lat1, lon1, lat2, lon2):
    """Distance in km between two points (broadcast-safe)."""
    R = 6371.0
    lat1, lon1 = np.radians(lat1), np.radians(lon1)
    lat2, lon2 = np.radians(lat2), np.radians(lon2)
    dphi = lat2 - lat1
    dlam = lon2 - lon1
    a = np.sin(dphi / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlam / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))

# ============================================================
# STATION METADATA
# ============================================================
def load_station_metadata(path):
    """Parse stations.txt in the ECA&D format."""
    if not os.path.exists(path):
        log_error(f"stations.txt not found: {path}")
        return pd.DataFrame([])
    
    rows = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                if line.startswith("EUROPEAN") or line.startswith("FILE FORMAT"):
                    continue
                if line.startswith("STAID"):
                    continue
                if "," not in line:
                    continue
                parts = [p.strip() for p in line.split(",")]
                if len(parts) < 6:
                    continue
                try:
                    staid = int(parts[0])
                    staname = parts[1]
                    country = parts[2]
                    lat_raw = parts[3]
                    lon_raw = parts[4]
                    hght = int(parts[5])
                except Exception:
                    continue
                rows.append({
                    "STAID": staid,
                    "STANAME": staname,
                    "CN": country,
                    "LAT": lat_raw,
                    "LON": lon_raw,
                    "HGHT": hght,
                })
    except Exception as e:
        log_error(f"Error reading stations.txt: {e}")
        return pd.DataFrame([])
    
    df = pd.DataFrame(rows)
    if df.empty:
        log_error("stations.txt parsed but resulted in EMPTY dataframe.")
        return df
    
    df["lat_deg"] = df["LAT"].apply(dms_to_deg)
    df["lon_deg"] = df["LON"].apply(dms_to_deg)
    df = df.dropna(subset=["lat_deg", "lon_deg"])
    
    if df.empty:
        log_error("stations.txt produced only invalid coordinates.")
    
    return df

# ============================================================
# CITY POLYGON
# ============================================================
def get_city_polygon(city: str) -> gpd.GeoDataFrame:
    """Get city polygon from GADM with robust error handling."""
    try:
        if not os.path.exists(PATH_GADM):
            raise FileNotFoundError(f"GADM file not found: {PATH_GADM}")
        
        gadm = gpd.read_file(PATH_GADM)
        
        # exact match on different admin levels
        for col in ["NAME_5", "NAME_4", "NAME_3", "NAME_2", "NAME_1"]:
            if col in gadm.columns:
                sub = gadm[gadm[col].astype(str).str.upper() == city.upper()]
                if not sub.empty:
                    return sub.iloc[[0]]
        
        # fuzzy match
        mask = gadm.apply(
            lambda r: r.astype(str).str.contains(city, case=False, regex=False).any(),
            axis=1,
        )
        sub = gadm[mask]
        if sub.empty:
            raise ValueError(f"City '{city}' not found in GADM.")
        return sub.iloc[[0]]
    
    except Exception as e:
        log_error(f"Error loading city polygon for {city}: {e}")
        raise

# ============================================================
# TX FILE DISCOVERY
# ============================================================
def get_all_tx_station_ids() -> List[int]:
    """Read all TX_STAID*.txt files and extract station IDs."""
    try:
        if not os.path.isdir(PATH_ECAD_TX_DIR):
            log_error(f"ECA_blend_tx directory not found: {PATH_ECAD_TX_DIR}")
            return []
        
        files = [f for f in os.listdir(PATH_ECAD_TX_DIR) 
                 if f.startswith("TX_STAID") and f.endswith(".txt")]
        ids = []
        for f in files:
            try:
                staid_str = f[8:14]
                ids.append(int(staid_str))
            except Exception as e:
                log_error(f"Could not parse STAID from filename {f}: {e}")
        
        if not ids:
            log_error("No TX_STAID*.txt files found in ECA_blend_tx.")
        
        return sorted(ids)
    
    except Exception as e:
        log_error(f"Error discovering TX station IDs: {e}")
        return []

# ============================================================
# STATION SELECTION TABLE
# ============================================================
def build_station_table(city_polygon: gpd.GeoDataFrame) -> pd.DataFrame:
    """Build station table with STAID and optional dist_km."""
    try:
        tx_ids = get_all_tx_station_ids()
        if not tx_ids:
            raise RuntimeError("No TX files found at all in ECA_blend_tx.")
        
        meta = load_station_metadata(PATH_STATIONS_META)
        
        # Have metadata and some overlap?
        if not meta.empty:
            meta["STAID_int"] = meta["STAID"].astype(int)
            intersect_ids = sorted(set(tx_ids).intersection(set(meta["STAID_int"])))
            
            if intersect_ids:
                meta_sel = meta[meta["STAID_int"].isin(intersect_ids)].copy()
                city4326 = city_polygon.to_crs("EPSG:4326")
                geom = city4326.geometry.iloc[0]
                center = geom.centroid
                clat, clon = center.y, center.x
                
                gdf = gpd.GeoDataFrame(
                    meta_sel,
                    geometry=gpd.points_from_xy(meta_sel["lon_deg"], meta_sel["lat_deg"]),
                    crs="EPSG:4326",
                )
                gdf["dist_km"] = haversine(clat, clon, gdf["lat_deg"], gdf["lon_deg"])
                
                # stations inside polygon
                inside = gdf[gdf.within(geom)]
                if not inside.empty:
                    return inside[["STAID_int", "dist_km"]].rename(columns={"STAID_int": "STAID"})
                
                # fallback: radius search
                for R in [50, 80, 120, 150]:
                    sub = gdf[gdf["dist_km"] <= R]
                    if not sub.empty:
                        return sub[["STAID_int", "dist_km"]].rename(columns={"STAID_int": "STAID"})
                
                # nothing near - return all intersect IDs
                return gdf[["STAID_int", "dist_km"]].rename(columns={"STAID_int": "STAID"})
            else:
                log_error("No overlap between TX station IDs and stations.txt metadata.")
        
        # Fallback: only TX filenames, no distances
        log_error("Falling back to TX filenames only (no distance info).")
        rows = [{"STAID": sid, "dist_km": np.nan} for sid in tx_ids]
        return pd.DataFrame(rows)
    
    except Exception as e:
        log_error(f"Error building station table: {e}")
        raise

# ============================================================
# ECAD LOADING
# ============================================================
def detect_header_skip(fpath: str) -> int:
    """Detect header rows to skip."""
    try:
        with open(fpath, "r", errors="ignore") as f:
            for i, line in enumerate(f):
                if "DATE" in line and "STAID" in line:
                    return i
    except Exception as e:
        log_error(f"detect_header_skip failed on {fpath}: {e}")
    return 0


def load_station_series(var: str, staid: int, base_dir: str, scale: float, y0: int, y1: int) -> Optional[pd.Series]:
    """Load and process single station time series, filtered by year range."""
    fname = f"{var}_STAID{staid:06d}.txt"
    fpath = os.path.join(base_dir, fname)
    try:
        if not os.path.exists(fpath):
            return None
        skip = detect_header_skip(fpath)
        df = pd.read_csv(fpath, skiprows=skip, engine="python", on_bad_lines="skip")
        df.columns = [c.strip() for c in df.columns]
        if "DATE" not in df.columns:
            log_error(f"File {fpath} has no DATE column.")
            return None
        df["date"] = pd.to_datetime(df["DATE"], format="%Y%m%d", errors="coerce")
        df = df[df["date"].notna()]
        
        # **NEW: Filter by year range**
        df = df[(df["date"].dt.year >= y0) & (df["date"].dt.year <= y1)]
        
        # Rest of the function remains the same...
        # value column
        valcol = None
        for c in df.columns:
            if c.upper() == var.upper():
                valcol = c
                break
        if valcol is None:
            log_error(f"No value column {var} found in {fpath}.")
            return None
        
        # quality
        qcol = None
        for c in df.columns:
            if c.upper().startswith("Q_") and var.upper() in c.upper():
                qcol = c
                break
        if qcol is not None and qcol in df.columns:
            if "Q_TG" in qcol:
                df = df[df[qcol].isin([0, -9])]  # Valid + metadata-missing
            else:
                df = df[df[qcol] == 0]  # Standard filtering for TX/TN/RR
        df = df[df[valcol] != -9999]
        if df.empty:
            return None
        df[valcol] = df[valcol].astype(float) * scale
        return df.set_index("date")[valcol].sort_index()
    except Exception as e:
        log_error(f"Error loading {fpath}: {e}")
        return None
# ============================================================
# ECAD CITY AGGREGATION
# ============================================================




def build_tx_city(stations_table: pd.DataFrame, y0: int, y1: int) -> Tuple[Optional[pd.Series], Optional[pd.DataFrame]]:
    """Build TX city average and panel data, filtered by year range."""
    try:
        series_list = []
        panel_rows = []
        safe_print("[STEP] Loading TX station series...")
        for _, row in tqdm(stations_table.iterrows(), total=len(stations_table), desc="TX stations", unit="sta"):
            sid = int(row['STAID'])
            s = load_station_series("TX", sid, PATH_ECAD_TX_DIR, 0.1, y0, y1)  # Added y0, y1
            if s is None or s.empty:
                continue
            series_list.append(s.rename(sid))
            # Build panel with optional dist_km and lcz_class
            for d, v in s.items():
                panel_row = {
                    'date': d,
                    'STAID': sid,
                    'TX_C': float(v)
                }
                # Add optional columns if they exist
                if 'dist_km' in row and pd.notna(row['dist_km']):
                    panel_row['dist_km'] = float(row['dist_km'])
                if 'lcz_class' in row and pd.notna(row['lcz_class']):
                    panel_row['lcz_class'] = int(row['lcz_class'])
                if 'lcz_type' in row and pd.notna(row['lcz_type']):
                    panel_row['lcz_type'] = row['lcz_type']
                panel_rows.append(panel_row)
        
        if not series_list:
            log_error("No valid TX series found for any station.")
            return None, None
        
        df = pd.concat(series_list, axis=1)
        city = df.mean(axis=1).rename("TX_C_city_mean")
        panel_df = pd.DataFrame(panel_rows)
        return city, panel_df
    except Exception as e:
        log_error(f"Error building TX city series: {e}")
        return None, None




def build_other_city(stations_table: pd.DataFrame, var: str, y0: int, y1: int) -> Optional[pd.Series]:
    """Build city-average series for other ECA variables, filtered by year range."""
    try:
        cfg = ECA_VAR_CONFIG.get(var)
        if cfg is None:
            return None
        base = cfg["dir"]
        scale = cfg["scale"]
        if not os.path.isdir(base):
            log_error(f"Directory for {var} not found: {base}")
            return None
        
        series_list = []
        safe_print(f"[STEP] Loading {var} station series...")
        for _, row in tqdm(stations_table.iterrows(), total=len(stations_table), desc=f"{var} stations", unit="sta"):
            sid = int(row["STAID"])
            s = load_station_series(var, sid, base, scale, y0, y1)  # Added y0, y1
            if s is None or s.empty:
                continue
            series_list.append(s.rename(sid))
        
        if not series_list:
            log_error(f"No valid {var} series found for selected stations.")
            return None
        
        df = pd.concat(series_list, axis=1)
        return df.mean(axis=1).rename(f"{var}_city_mean")
    except Exception as e:
        log_error(f"Error building {var} city series: {e}")
        return None
# ============================================================
# ERA5 LOADER
# ============================================================



def load_city_era5(city_polygon: gpd.GeoDataFrame, y0: int, y1: int) -> Optional[pd.DataFrame]:
    """Load ERA5 data for city with robust error handling."""
    try:
        # ===== DIAGNOSTIC: Check if files exist =====
        safe_print(f"\n[DEBUG] Checking ERA5 directory: {PATH_ERA5_DIR}")
        if not os.path.isdir(PATH_ERA5_DIR):
            log_error(f"ERA5 directory not found: {PATH_ERA5_DIR}")
            safe_print("[DEBUG] DIRECTORY NOT FOUND")
            return None
        
        # List actual files
        nc_files = [f for f in os.listdir(PATH_ERA5_DIR) if f.endswith('.nc')]
        safe_print(f"[DEBUG] Found {len(nc_files)} NetCDF files")
        safe_print(f"[DEBUG] First 5 files: {nc_files[:5]}")
        
        # Check for required temperature files
        for year in [2020, 2025]:  # Check first and last year
            for temp_type in ["maximum", "minimum"]:
                fname = f"{year}_2m_temperature_daily_{temp_type}.nc"
                fpath = os.path.join(PATH_ERA5_DIR, fname)
                exists = os.path.exists(fpath)
                safe_print(f"[DEBUG] {fname}: {'✓ FOUND' if exists else ' MISSING'}")
        # ===== END DIAGNOSTIC =====
        
        city4326 = city_polygon.to_crs("EPSG:4326")
        out = {}
        safe_print("[STEP] Loading ERA5 datasets...")
        
        for key, patt in ERA5_FILE_PATTERNS.items():
            safe_print(f"  Loading {key}...")
            varname = ERA5_VAR_NAMES[key]
            series_list = []
            years = list(range(y0, y1 + 1))
            
            for year in years:
                fpath = os.path.join(PATH_ERA5_DIR, patt.format(year=year))
                if not os.path.exists(fpath):
                    continue
                    
                try:
                    ds = xr.open_dataset(fpath)
                    
                    # Try clipping
                    try:
                        ds = ds.rio.write_crs("EPSG:4326")
                        ds_clip = ds.rio.clip(city4326.geometry, drop=False)
                    except Exception as e:
                        log_error(f"ERA5 clip failed for {fpath}: {e}")
                        ds_clip = ds
                    
                    # Get variable
                    if varname not in ds_clip.data_vars:
                        varname_use = list(ds_clip.data_vars)[0]
                    else:
                        varname_use = varname
                    
                    da = ds_clip[varname_use]
                    
                    # Spatial average
                    dims = da.dims
                    if "latitude" in dims and "longitude" in dims:
                        da_mean = da.mean(dim=["latitude", "longitude"])
                    elif "lat" in dims and "lon" in dims:
                        da_mean = da.mean(dim=["lat", "lon"])
                    else:
                        spatial_dims = [d for d in dims if d != "time"]
                        if spatial_dims:
                            da_mean = da.mean(dim=spatial_dims)
                        else:
                            da_mean = da
                    
                    s = da_mean.to_pandas()
                    series_list.append(s)
                    
                except Exception as e:
                    log_error(f"Error loading {fpath}: {e}")
                    continue
            
            if series_list:
                merged = pd.concat(series_list).sort_index()
                
                # CHECK FOR DUPLICATE DATES
                if merged.index.duplicated().any():
                    safe_print(f"[DEBUG] Found {merged.index.duplicated().sum()} duplicate dates in {key}")
                    merged = merged[~merged.index.duplicated(keep='first')]  # Keep first occurrence
                
                # CORRECT COLUMN MAPPING:
                colname = {
                    "t2m_max": "ERA5_t2m_max_K",
                    "t2m_min": "ERA5_t2m_min_K",
                    "tp": "ERA5_tp_m",
                    "u10": "ERA5_u10_ms",
                    "v10": "ERA5_v10_ms",
                }[key]
                
                out[colname] = merged
        
        if not out:
            log_error("No ERA5 time series could be constructed.")
            safe_print("[DEBUG] No ERA5 data loaded")
            return None
        
        # Create dataframe
        all_dates = sorted({d for s in out.values() for d in s.index})




        era5_df = pd.DataFrame(index=all_dates)  # Changed variable name from df to era5_df
        for col, s in out.items():
            era5_df[col] = s.reindex(era5_df.index)

        # Convert temperature from K to C
        if "ERA5_t2m_max_K" in era5_df.columns:
            era5_df["ERA5_t2m_max_C"] = era5_df["ERA5_t2m_max_K"] - 273.15
            era5_df.drop(columns=["ERA5_t2m_max_K"], inplace=True)
            safe_print(f"[DEBUG] ERA5 max temp loaded: {era5_df['ERA5_t2m_max_C'].notna().sum()} values")
        
        if "ERA5_t2m_min_K" in era5_df.columns:
            era5_df["ERA5_t2m_min_C"] = era5_df["ERA5_t2m_min_K"] - 273.15
            era5_df.drop(columns=["ERA5_t2m_min_K"], inplace=True)
            safe_print(f"[DEBUG] ERA5 min temp loaded: {era5_df['ERA5_t2m_min_C'].notna().sum()} values")

        # FIX DUPLICATE INDEX LABELS
        if era5_df.index.duplicated().any():  # Changed df to era5_df
            safe_print(f"[DEBUG] Final fix: {era5_df.index.duplicated().sum()} duplicate indices")
            era5_df = era5_df[~era5_df.index.duplicated(keep='first')]
        
        safe_print(f"[DEBUG] ERA5 shape after loading: {era5_df.shape}")
        era5_df.index.name = "date"
        return era5_df.reset_index()  # Changed df to era5_df
        
    except Exception as e:
        log_error(f"Error loading ERA5 data: {e}")
        safe_print(f"[DEBUG] Exception: {e}")
        return None
        
    except Exception as e:
        log_error(f"Error loading ERA5 data: {e}")
        safe_print(f"[DEBUG] Exception: {e}")
        return None
# ============================================================
# NDVI LOADER
# ============================================================
def load_city_ndvi(city_polygon: gpd.GeoDataFrame, y0: int, y1: int):
    """Load NDVI with windowed reads and robust error handling, filtered by year range."""
    try:
        if rasterio is None:
            log_error("rasterio not installed - NDVI disabled.")
            return None
        if not os.path.isdir(PATH_NDVI_DIR):
            log_error(f"NDVI directory not found: {PATH_NDVI_DIR}")
            return None
        
        city3035 = city_polygon.to_crs("EPSG:3035")
        bounds = city3035.total_bounds
        xmin, ymin, xmax, ymax = bounds
        results = []
        
        for fname in sorted(os.listdir(PATH_NDVI_DIR)):
            if not (fname.startswith("ndvi_") and fname.endswith(".tif")):
                continue
            try:
                part = fname.replace("ndvi_", "").replace(".tif", "")
                start_str, end_str = part.split("_")
                d0 = pd.to_datetime(start_str)
            except Exception as e:
                log_error(f"NDVI filename parse failed: {fname}: {e}")
                continue
            
            # **NEW: Filter by year range**
            if not (y0 <= d0.year <= y1):
                continue
            
            fpath = os.path.join(PATH_NDVI_DIR, fname)
            try:
                with rasterio.open(fpath) as ds:
                    row_min, col_min = ds.index(xmin, ymax)
                    row_max, col_max = ds.index(xmax, ymin)
                    r0, r1 = sorted([row_min, row_max])
                    c0, c1 = sorted([col_min, col_max])
                    r0 = max(r0, 0)
                    c0 = max(c0, 0)
                    r1 = min(r1, ds.height)
                    c1 = min(c1, ds.width)
                    if r1 <= r0 or c1 <= c0:
                        continue
                    window = rasterio.windows.Window(
                        col_off=c0, row_off=r0, width=c1 - c0, height=r1 - r0
                    )
                    arr = ds.read(1, window=window)
            except Exception as e:
                log_error(f"NDVI read failed for {fname}: {e}")
                continue
            
            arr = arr.astype("float32")
            arr[arr == 255] = np.nan
            arr = (arr / 127.0) - 1.0
            m = np.nanmean(arr)
            if np.isnan(m):
                continue
            results.append((d0, m))
        
        if not results:
            log_error("NDVI: no valid windows extracted.")
            return None
        
        results.sort(key=lambda x: x[0])
        idx = pd.DatetimeIndex([x[0] for x in results])
        s = pd.Series([x[1] for x in results], index=idx, name="NDVI_city")
        full = pd.date_range(idx.min(), idx.max(), freq="D")
        return s.reindex(full).ffill()
    except Exception as e:
        log_error(f"Error loading NDVI: {e}")
        return None
# ============================================================
# METRICS (All with try-except wrappers)
# ============================================================
def safe_metric(func):
    """Decorator to wrap metric functions in try-except."""
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            log_error(f"Metric {func.__name__} failed: {e}")
            return None
    return wrapper

@safe_metric



@safe_metric
def pair_metrics(df: pd.DataFrame, model_col: str, obs_col: str) -> Optional[Dict]:
    """
    Calculate pair-wise metrics between model and observations.
    
    This function computes standard validation metrics (bias, RMSE, MAE, correlation)
    and includes a leave-one-out cross-validation (LOO) RMSE to detect spatial 
    overfitting - critical for state-of-art validation of gridded vs point data.
    
    Args:
        df: DataFrame containing model and observation columns
        model_col: Name of model column (e.g., "ERA5_t2m_max_C")
        obs_col: Name of observation column (e.g., "TX_C_city_mean")
    
    Returns:
        Dictionary of metrics or None if insufficient data
    """
    if model_col not in df.columns or obs_col not in df.columns:
        log_error(f"Missing columns for pair_metrics: {model_col}, {obs_col}")
        return None
    
    sub = df[[model_col, obs_col]].dropna()
    if len(sub) < 10:
        log_error(f"Insufficient data for pair_metrics: {len(sub)} points")
        return None
    
    # Basic metrics
    diff = sub[model_col] - sub[obs_col]
    out = {
        "n": int(len(sub)),
        "mean_bias": float(diff.mean()),
        "rmse": float(np.sqrt(np.mean(diff ** 2))),
        "mae": float(np.mean(np.abs(diff))),
        "corr": float(sub[model_col].corr(sub[obs_col])),
    }
    
    # Hot conditions (90th percentile)
    q90 = sub[obs_col].quantile(0.9)
    hot = sub[sub[obs_col] >= q90]
    if len(hot) > 5:
        dh = hot[model_col] - hot[obs_col]
        out["hot_bias"] = float(dh.mean())
        out["hot_rmse"] = float(np.sqrt(np.mean(dh ** 2)))
    
    # Statistical distribution test
    if stats is not None:
        try:
            ks = stats.ks_2samp(sub[model_col], sub[obs_col])
            out["ks_stat"] = float(ks.statistic)
            out["ks_p"] = float(ks.pvalue)
        except Exception as e:
            log_error(f"KS test failed: {e}")

    # This detects overfitting when stations are sparse and ERA5 is too smooth
    if "STAID" in df.columns:
        loo_rmses = []
        station_groups = sub.groupby(df.loc[sub.index, 'STAID'])
        
        for sid, group in station_groups:
            if len(group) < 5:
                continue  # Skip stations with too few points
                
            # Training data: all other stations
            train_data = sub[sub.index.isin(group.index) == False]
            if len(train_data) < 10:
                continue
                
            # Test data: this station
            test_data = group
            
            # Calculate bias on training data
            train_bias = train_data[model_col] - train_data[obs_col]
            mean_train_bias = train_bias.mean()
            
            # Apply to test data
            test_bias = test_data[model_col] - test_data[obs_col]
            loo_rmse = np.sqrt(np.mean((test_bias - mean_train_bias) ** 2))
            loo_rmses.append(loo_rmse)
        
        out["loo_rmse"] = float(np.mean(loo_rmses)) if loo_rmses else None
        out["n_stations_loo"] = len(loo_rmses)
        
        if out["loo_rmse"] and out["rmse"]:
            overfit_factor = out["loo_rmse"] / out["rmse"]
            if overfit_factor > 1.5:
                log_error(f"SPATIAL OVERFITTING DETECTED: LOO RMSE is {overfit_factor:.1f}x higher than RMSE!")
    
    return out
@safe_metric
def compute_uhi(tx_panel: Optional[pd.DataFrame]) -> Optional[Dict]:
    """Mean UHI intensity based on near/far stations."""
    if tx_panel is None or tx_panel.empty:
        return None
    if "dist_km" not in tx_panel.columns:
        return None
    
    df = tx_panel.copy()
    df["date"] = pd.to_datetime(df["date"])
    uhi_vals = []
    
    for dt, sub in df.groupby("date"):
        urb = sub[sub["dist_km"] < 5]["TX_C"]
        rur = sub[sub["dist_km"] > 15]["TX_C"]
        if len(urb) == 0 or len(rur) == 0:
            continue
        uhi_vals.append(float(urb.mean() - rur.mean()))
    
    if not uhi_vals:
        return None
    
    arr = np.array(uhi_vals)
    return {
        "n_days": int(len(arr)),
        "mean": float(arr.mean()),
        "median": float(np.median(arr)),
        "p90": float(np.quantile(arr, 0.9)),
        "max": float(arr.max()),
    }







@safe_metric
def heatwave_stats(df: pd.DataFrame) -> Optional[Dict]:
    """State-of-art heatwave: TX > 30°C for ≥3 consecutive days."""
    if "TX_C_city_mean" not in df.columns:
        return None
    
    tx = df["TX_C_city_mean"].dropna()
    if tx.empty:
        return None
    
    ABSOLUTE_THRESHOLD = 30.0  # Berlin heatwave definition (WMO)
    is_hw = tx > ABSOLUTE_THRESHOLD
    
    hw_events = []
    current = 0
    
    for flag in is_hw:
        if flag:
            current += 1
        else:
            if current >= 3:  # Minimum 3 days
                hw_events.append(current)
            current = 0
    
    if current >= 3:
        hw_events.append(current)
    
    if not hw_events:
        return {"count": 0, "mean_length": 0, "max_length": 0}
    
    return {
        "count": len(hw_events),
        "mean_length": float(np.mean(hw_events)),
        "max_length": int(max(hw_events))
    }


@safe_metric
def cold_spell_stats(df: pd.DataFrame) -> Optional[Dict]:
    """Cold spell metric based on TN city mean."""
    if "TN_C_city_mean" not in df.columns:
        return None
    
    tn = df["TN_C_city_mean"].dropna()
    if tn.empty:
        return None
    
    threshold = tn.quantile(0.1)
    is_cs = tn < threshold
    events = []
    current = 0
    
    for flag in is_cs:
        if flag:
            current += 1
        else:
            if current >= 3:
                events.append(current)
            current = 0
    
    if current >= 3:
        events.append(current)
    
    if not events:
        return {"count": 0, "mean_length": 0, "max_length": 0}
    
    return {
        "count": len(events),
        "mean_length": float(np.mean(events)),
        "max_length": int(max(events))
    }







@safe_metric
def seasonal_means(df: pd.DataFrame, y0: int = 2020, y1: int = 2025) -> Dict:
    """Seasonal mean TX and total RR for analysis period only."""
    if "date" not in df.columns:
        return {}

    df_period = df[(df['date'].dt.year >= y0) & (df['date'].dt.year <= y1)].copy()
    df2 = df_period.set_index("date")

    if not isinstance(df2.index, pd.DatetimeIndex):
        df2.index = pd.to_datetime(df2.index)

    df2["season"] = df2.index.month % 12 // 3
    seasons = {0: "winter", 1: "spring", 2: "summer", 3: "autumn"}
    out = {}

    for s, val in seasons.items():
        sub = df2[df2["season"] == s]
        if not sub.empty:
            # Calculate SEASONAL mean temperature (correct)
            temp_mean_val = float(sub["TX_C_city_mean"].mean()) if "TX_C_city_mean" in sub.columns else None
            
            # --- FIX FOR PRECIPITATION ---
            # Calculate mean DAILY precipitation for the season, then scale to seasonal total.
            if "RR_mm_city_mean" in sub.columns:
                # 1. Get the daily series (still in 0.1mm units)
                daily_precip_series = sub["RR_mm_city_mean"]
                # 2. Convert daily mean from 0.1mm to mm, then multiply by days in season
                mean_daily_mm = daily_precip_series.mean() * 0.1
                days_in_season = len(daily_precip_series)
                precip_sum_val = mean_daily_mm * days_in_season
            else:
                precip_sum_val = None
            # --- END FIX ---

            out[val] = {
                "temp_mean": temp_mean_val,
                "precip_sum": precip_sum_val  # Now in mm, for the season only
            }
    
    return out


@safe_metric
def wind_heat_relation(df: pd.DataFrame) -> Optional[Dict]:
    """Correlation TX vs wind, plus mean wind on hot days."""
    if "TX_C_city_mean" not in df.columns or "FG_ms_city_mean" not in df.columns:
        return None
    
    sub = df[["TX_C_city_mean", "FG_ms_city_mean"]].dropna()
    if len(sub) < 30:
        return None
    
    return {
        "corr_temp_wind": float(sub.corr().iloc[0, 1]),
        "mean_hotday_wind": float(
            sub[sub["TX_C_city_mean"] > sub["TX_C_city_mean"].quantile(0.9)]["FG_ms_city_mean"].mean()
        )
    }

@safe_metric
def precip_extremes(df: pd.DataFrame) -> Optional[Dict]:
    """99th percentile precipitation & count."""
    if "RR_mm_city_mean" not in df.columns:
        return None
    
    rr = df["RR_mm_city_mean"].dropna()
    if rr.empty:
        return None
    
    q99 = rr.quantile(0.99)
    extreme_days = rr[rr >= q99]
    
    return {
        "top1pct_threshold": float(q99),
        "extreme_day_count": int(len(extreme_days)),
        "extreme_day_mean": float(extreme_days.mean())
    }

@safe_metric
def uhi_trend(tx_panel: Optional[pd.DataFrame]) -> Optional[Dict]:
    """Trend of UHI intensity (°C/year) from panel."""
    if LinearRegression is None:
        return None
    if tx_panel is None or tx_panel.empty:
        return None
    if "dist_km" not in tx_panel.columns:
        return None
    
    daily = []
    for dt, sub in tx_panel.groupby("date"):
        urb = sub[sub["dist_km"] < 5]["TX_C"]
        rur = sub[sub["dist_km"] > 15]["TX_C"]
        if len(urb) > 0 and len(rur) > 0:
            daily.append((pd.to_datetime(dt), float(urb.mean() - rur.mean())))
    
    if not daily:
        return None
    
    dates = np.array([d[0].toordinal() for d in daily]).reshape(-1, 1)
    values = np.array([d[1] for d in daily])
    model = LinearRegression().fit(dates, values)
    slope = model.coef_[0]
    
    return {
        "trend_per_year": float(slope * 365.0),
        "direction": "increasing" if slope > 0 else "decreasing"
    }

@safe_metric
def temp_variability(df: pd.DataFrame) -> Optional[Dict]:
    """Overall variability of TX."""
    if "TX_C_city_mean" not in df.columns:
        return None
    
    tx = df["TX_C_city_mean"].dropna()
    if tx.empty:
        return None
    
    return {
        "std_temp": float(tx.std()),
        "iqr_temp": float(tx.quantile(0.75) - tx.quantile(0.25))
    }

@safe_metric
def bias_stability(df: pd.DataFrame) -> Optional[Dict]:
    """Smoothness of ERA5-station bias over time."""
    if "ERA5_t2m_max_C" not in df.columns or "TX_C_city_mean" not in df.columns:
        return None
    
    sub = df[["ERA5_t2m_max_C", "TX_C_city_mean"]].dropna()
    if len(sub) < 30:
        return None
    
    bias = sub["ERA5_t2m_max_C"] - sub["TX_C_city_mean"]
    roll = bias.rolling(30).std()
    
    return {"rolling_bias_std": float(roll.mean())}

@safe_metric
def wet_dry_stats(df: pd.DataFrame) -> Optional[Dict]:
    """Compare TX on wet vs dry days."""
    if "RR_mm_city_mean" not in df.columns or "TX_C_city_mean" not in df.columns:
        return None
    
    sub = df.dropna(subset=["RR_mm_city_mean", "TX_C_city_mean"])
    if sub.empty:
        return None
    
    wet = sub[sub["RR_mm_city_mean"] > 1.0]
    dry = sub[sub["RR_mm_city_mean"] <= 1.0]
    
    return {
        "wet_count": int(len(wet)),
        "dry_count": int(len(dry)),
        "wet_temp_mean": float(wet["TX_C_city_mean"].mean()) if len(wet) else None,
        "dry_temp_mean": float(dry["TX_C_city_mean"].mean()) if len(dry) else None,
    }

@safe_metric
def regime_metrics(df: pd.DataFrame) -> Optional[Dict]:
    """Calm vs windy regime temperature difference."""
    if "FG_ms_city_mean" not in df.columns or "TX_C_city_mean" not in df.columns:
        return None
    
    df2 = df.dropna(subset=["FG_ms_city_mean", "TX_C_city_mean"])
    if df2.empty:
        return None
    
    q25 = df2["FG_ms_city_mean"].quantile(0.25)
    q75 = df2["FG_ms_city_mean"].quantile(0.75)
    
    calm = df2[df2["FG_ms_city_mean"] < q25]
    windy = df2[df2["FG_ms_city_mean"] > q75]
    
    if calm.empty or windy.empty:
        return None
    
    calm_mean = float(calm["TX_C_city_mean"].mean())
    windy_mean = float(windy["TX_C_city_mean"].mean())
    
    return {
        "calm_mean_temp": calm_mean,
        "windy_mean_temp": windy_mean,
        "difference": float(calm_mean - windy_mean)
    }

@safe_metric
def ndvi_temp_metrics(df: pd.DataFrame) -> Optional[Dict]:
    """Correlation between NDVI anomalies and temp anomalies."""
    if "NDVI_city_anom" not in df.columns:
        return None
    
    out = {}
    if "TX_C_city_mean_anom" in df.columns:
        sub = df[["NDVI_city_anom", "TX_C_city_mean_anom"]].dropna()
        if len(sub) > 10:
            out["corr_ndvi_tx"] = float(sub["NDVI_city_anom"].corr(sub["TX_C_city_mean_anom"]))
    
    if "ERA5_t2m_max_C_anom" in df.columns:
        sub = df[["NDVI_city_anom", "ERA5_t2m_max_C_anom"]].dropna()
        if len(sub) > 10:
            out["corr_ndvi_era5"] = float(sub["NDVI_city_anom"].corr(sub["ERA5_t2m_max_C_anom"]))
    
    return out or None

@safe_metric
def bias_distribution_metrics(df: pd.DataFrame) -> Optional[Dict]:
    """Shape of ERA5-station bias distribution."""
    if "ERA5_t2m_max_C" not in df.columns or "TX_C_city_mean" not in df.columns:
        return None
    
    sub = df[["ERA5_t2m_max_C", "TX_C_city_mean"]].dropna()
    if len(sub) < 10:
        return None
    
    bias = sub["ERA5_t2m_max_C"] - sub["TX_C_city_mean"]
    return {
        "mean": float(bias.mean()),
        "std": float(bias.std()),
        "skew": float(bias.skew()),
        "kurtosis": float(bias.kurtosis())
    }

@safe_metric
def bias_quantile_curve(df: pd.DataFrame, n: int = 10) -> Optional[Dict]:
    """Bias as a function of observed TX quantiles."""
    if "ERA5_t2m_max_C" not in df.columns or "TX_C_city_mean" not in df.columns:
        return None
    
    sub = df[["ERA5_t2m_max_C", "TX_C_city_mean"]].dropna()
    if len(sub) < 50:
        return None
    
    ranks = sub["TX_C_city_mean"].rank(pct=True)
    sub = sub.assign(obs_q=ranks)
    qs = np.linspace(0, 1, n + 1)
    res = {}
    
    for i in range(n):
        lo, hi = qs[i], qs[i + 1]
        mask = (sub["obs_q"] > lo) & (sub["obs_q"] <= hi)
        tmp = sub[mask]
        if len(tmp) < 5:
            continue
        key = f"{int(lo * 100)}-{int(hi * 100)}"
        res[key] = float((tmp["ERA5_t2m_max_C"] - tmp["TX_C_city_mean"]).mean())
    
    return res or None

@safe_metric
def uhi_day_night(tx_panel):
    """Computes daytime (TX) and nighttime (TN) UHI intensities."""
    if tx_panel is None or tx_panel.empty:
        return None
    if "dist_km" not in tx_panel.columns:
        return None
    if "TX_C" not in tx_panel.columns:
        return None
    
    out = {}
    daily = {}
    for dt, sub in tx_panel.groupby("date"):
        urb = sub[sub["dist_km"] < 5]["TX_C"]
        rur = sub[sub["dist_km"] > 15]["TX_C"]
        if len(urb) > 0 and len(rur) > 0:
            daily[dt] = urb.mean() - rur.mean()
    
    if daily:
        out["UHI_day_mean"] = float(np.mean(list(daily.values())))
        out["UHI_day_p90"] = float(np.quantile(list(daily.values()), 0.9))
    
    return out if out else None

@safe_metric
def seasonal_uhi(tx_panel):
    """UHI by season."""
    if tx_panel is None or tx_panel.empty:
        return None
    
    tx_panel = tx_panel.copy()
    tx_panel["date"] = pd.to_datetime(tx_panel["date"])
    tx_panel["season"] = tx_panel["date"].dt.month % 12 // 3
    
    out = {}
    seasons = {0: "winter", 1: "spring", 2: "summer", 3: "autumn"}
    
    for s, name in seasons.items():
        sub = tx_panel[tx_panel["season"] == s]
        if sub.empty:
            continue
        
        urb = sub[sub["dist_km"] < 5].groupby("date")["TX_C"].mean()
        rur = sub[sub["dist_km"] > 15].groupby("date")["TX_C"].mean()
        aligned = pd.concat([urb, rur], axis=1).dropna()
        
        if aligned.empty:
            continue
        
        uhi_vals = aligned.iloc[:, 0] - aligned.iloc[:, 1]
        out[name] = {
            "mean": float(uhi_vals.mean()),
            "p90": float(uhi_vals.quantile(0.9)),
            "max": float(uhi_vals.max())
        }
    
    return out

@safe_metric
def uhi_wind_conditioned(df, tx_panel):
    """UHI conditioned on wind speed."""
    if tx_panel is None or tx_panel.empty:
        return None
    if "FG_ms_city_mean" not in df.columns:
        return None
    
    df2 = df.set_index("date")
    tx_panel["date"] = pd.to_datetime(tx_panel["date"])
    merged = tx_panel.merge(df2["FG_ms_city_mean"], left_on="date", right_index=True)
    
    if merged.empty:
        return None
    
    uhi_daily = []
    for dt, sub in merged.groupby("date"):
        urb = sub[sub["dist_km"] < 5]["TX_C"]
        rur = sub[sub["dist_km"] > 15]["TX_C"]
        if len(urb) > 0 and len(rur) > 0:
            uhi_daily.append((dt, urb.mean() - rur.mean(), sub["FG_ms_city_mean"].iloc[0]))
    
    if not uhi_daily:
        return None
    
    dfu = pd.DataFrame(uhi_daily, columns=["date", "uhi", "wind"])
    calm = dfu[dfu["wind"] < dfu["wind"].quantile(0.25)]
    windy = dfu[dfu["wind"] > dfu["wind"].quantile(0.75)]
    
    return {
        "calm_uhi_mean": float(calm["uhi"].mean()),
        "windy_uhi_mean": float(windy["uhi"].mean()),
        "difference": float(calm["uhi"].mean() - windy["uhi"].mean())
    }

@safe_metric
def ndvi_temp_elasticity(df):
    """Linear elasticity of temp vs NDVI."""
    if LinearRegression is None:
        return None
    if "NDVI_city" not in df or "TX_C_city_mean" not in df:
        return None
    
    sub = df[["NDVI_city", "TX_C_city_mean"]].dropna()
    if len(sub) < 30:
        return None
    
    X = sub["NDVI_city"].values.reshape(-1, 1)
    y = sub["TX_C_city_mean"].values
    model = LinearRegression().fit(X, y)
    
    return {
        "elasticity_C_per_NDVI": float(model.coef_[0]),
        "intercept": float(model.intercept_),
        "corr": float(sub.corr().iloc[0, 1])
    }

@safe_metric
def bias_by_ndvi_bin(df):
    """Bias stratified by NDVI bins."""
    if "NDVI_city" not in df or "ERA5_t2m_max_C" not in df or "TX_C_city_mean" not in df:
        return None
    
    df = df.dropna(subset=["NDVI_city", "ERA5_t2m_max_C", "TX_C_city_mean"]).copy()
    df["bias"] = df["ERA5_t2m_max_C"] - df["TX_C_city_mean"]
    
    bins = [-1, 0.2, 0.5, 1.0]
    labels = ["built_up", "mixed", "green"]
    df["ndvi_class"] = pd.cut(df["NDVI_city"], bins=bins, labels=labels)
    
    out = {}
    for cl in labels:
        sub = df[df["ndvi_class"] == cl]
        if len(sub) > 20:
            out[cl] = {
                "mean_bias": float(sub["bias"].mean()),
                "rmse": float(np.sqrt(np.mean(sub["bias"] ** 2))),
                "count": int(len(sub))
            }
    
    return out

@safe_metric
def temp_regime_bias(df):
    """Bias stratified by temperature regime."""
    if "ERA5_t2m_max_C" not in df or "TX_C_city_mean" not in df:
        return None
    
    df2 = df.dropna(subset=["ERA5_t2m_max_C", "TX_C_city_mean"]).copy()
    df2["bias"] = df2["ERA5_t2m_max_C"] - df2["TX_C_city_mean"]
    
    regimes = {
        "below_0": df2[df2["TX_C_city_mean"] < 0],
        "0_10": df2[(df2["TX_C_city_mean"] >= 0) & (df2["TX_C_city_mean"] < 10)],
        "10_20": df2[(df2["TX_C_city_mean"] >= 10) & (df2["TX_C_city_mean"] < 20)],
        "20_30": df2[(df2["TX_C_city_mean"] >= 20) & (df2["TX_C_city_mean"] < 30)],
        "above_30": df2[df2["TX_C_city_mean"] >= 30],
    }
    
    out = {}
    for k, sub in regimes.items():
        if len(sub) > 10:
            out[k] = {
                "mean_bias": float(sub["bias"].mean()),
                "rmse": float(np.sqrt(np.mean(sub["bias"] ** 2))),
                "count": int(len(sub))
            }
    
    return out

@safe_metric
def heatwave_bias(df):
    """Bias during heatwave conditions."""
    if "TX_C_city_mean" not in df or "ERA5_t2m_max_C" not in df:
        return None
    
    sub = df.dropna(subset=["TX_C_city_mean", "ERA5_t2m_max_C"]).copy()
    thresh = sub["TX_C_city_mean"].quantile(0.9)
    hw = sub[sub["TX_C_city_mean"] >= thresh]
    
    if len(hw) < 5:
        return None
    
    bias = hw["ERA5_t2m_max_C"] - hw["TX_C_city_mean"]
    return {
        "threshold_90th": float(thresh),
        "mean_bias": float(bias.mean()),
        "rmse": float(np.sqrt(np.mean(bias ** 2))),
        "max_underestimate": float(np.min(bias)),
        "count": int(len(hw))
    }

# ============================================================
# MAIN PIPELINE
# ============================================================
def add_anomalies(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    """Center variables by their mean to get anomalies."""
    for c in cols:
        if c in df.columns:
            df[c + "_anom"] = df[c] - df[c].mean()
    return df



















































# ============================================================
# ADD THESE NEW FUNCTIONS (after your existing imports)
# ============================================================

def load_lcz_raster(city_name: str):
    """Load WUDAPT LCZ raster for a city."""
    lcz_path = os.path.join(BASE_DIR, "WUDAPT", f"{city_name}.tif")
    
    if not os.path.exists(lcz_path):
        log_error(f"WUDAPT LCZ file not found: {lcz_path}")
        return None
    
    try:
        dataset = rasterio.open(lcz_path)
        safe_print(f"[INFO] Loaded LCZ raster: {city_name}.tif")
        return dataset
    except Exception as e:
        log_error(f"Failed to open LCZ raster: {e}")
        return None


def extract_lcz_for_stations(stations_df: pd.DataFrame, lcz_dataset) -> pd.DataFrame:
    """Extract LCZ class for each station using spatial sampling."""
    if lcz_dataset is None:
        return stations_df
    
    stations = stations_df.copy()
    
    try:
        from pyproj import Transformer
        transformer = Transformer.from_crs("EPSG:4326", lcz_dataset.crs, always_xy=True)
    except Exception as e:
        log_error(f"Coordinate transformation failed: {e}")
        return stations_df
    
    lcz_classes = []
    
    safe_print(f"[STEP] Extracting LCZ classes for {len(stations)} stations...")
    
    for idx, row in tqdm(stations.iterrows(), total=len(stations), desc="LCZ extraction", unit="sta"):
        try:
            x, y = transformer.transform(row['lon_deg'], row['lat_deg'])
            
            # Sample 3x3 grid around station (250m radius)
            buffer_m = 250
            offsets = np.linspace(-buffer_m, buffer_m, 3)
            sample_coords = [(x + dx, y + dy) for dx in offsets for dy in offsets]
            
            row_col_pairs = [lcz_dataset.index(coord[0], coord[1]) for coord in sample_coords]
            
            lcz_values = []
            for r, c in row_col_pairs:
                if 0 <= r < lcz_dataset.height and 0 <= c < lcz_dataset.width:
                    val = lcz_dataset.read(1, window=((r, r+1), (c, c+1)))[0, 0]
                    if val > 0:
                        lcz_values.append(int(val))
            
            if lcz_values:
                lcz_value = int(np.round(np.median(lcz_values)))
            else:
                lcz_value = 0
            
            lcz_classes.append(lcz_value)
            
        except Exception as e:
            log_error(f"LCZ extraction failed for station {row['STAID']}: {e}")
            lcz_classes.append(0)
    
    stations['lcz_class'] = lcz_classes
    
    # Map to urban/rural/exclude
    LCZ_MAP = {
        1: 'urban', 2: 'urban', 3: 'urban', 4: 'urban', 5: 'urban', 6: 'urban',
        7: 'exclude', 8: 'urban', 9: 'urban', 10: 'urban',
        11: 'rural', 12: 'rural', 13: 'rural', 14: 'rural', 15: 'rural', 16: 'rural',
        17: 'exclude', 0: 'exclude'
    }
    
    stations['lcz_type'] = stations['lcz_class'].map(LCZ_MAP)
    
    summary = stations['lcz_type'].value_counts()
    safe_print(f"[INFO] LCZ classification: Urban={summary.get('urban', 0)}, Rural={summary.get('rural', 0)}, Exclude={summary.get('exclude', 0)}")
    
    return stations





def select_uhi_stations_lcz(stations_df: pd.DataFrame, city_polygon: gpd.GeoDataFrame) -> Optional[Dict]:
    """Select station pairs for UHI using LCZ classification."""
    
    if 'lcz_type' not in stations_df.columns:
        log_error("No LCZ classification available - cannot compute UHI")
        return None
    
    urban = stations_df[stations_df['lcz_type'] == 'urban'].copy()
    rural = stations_df[stations_df['lcz_type'] == 'rural'].copy()
    
    safe_print(f"[INFO] Initial LCZ selection: {len(urban)} urban, {len(rural)} rural stations")
    
    if len(urban) == 0:
        log_error("No urban LCZ stations found! Check if Berlin.tif covers your station locations.")
        return None
    
    if len(rural) == 0:
        log_error("No rural LCZ stations found! This may mean:")
        log_error("  1. All your stations are inside Berlin city boundaries")
        log_error("  2. You need stations further from the city (>20km)")
        log_error("  3. The WUDAPT classification doesn't extend far enough")
        log_error("Continuing WITHOUT UHI calculation...")
        return None
    
    # Elevation matching
    if 'HGHT' in urban.columns and 'HGHT' in rural.columns:
        urban_elev = urban['HGHT'].mean()
        rural['elev_diff'] = abs(rural['HGHT'] - urban_elev)
        
        rural_matched = rural[rural['elev_diff'] < 100].copy()
        
        if len(rural_matched) >= 2:
            rural = rural_matched
            safe_print(f"[INFO] Elevation matched: {len(rural)} rural stations within 100m")
        elif len(rural_matched) > 0:
            rural = rural_matched
            safe_print(f"[WARNING] Only {len(rural_matched)} rural station(s) within elevation range")
    
    try:
        city_4326 = city_polygon.to_crs("EPSG:4326")
        # Get the FIRST polygon from MultiPolygon
        geom = city_4326.geometry.iloc[0]
        if geom.geom_type == 'MultiPolygon':
            # Use the largest polygon from MultiPolygon
            largest = max(geom.geoms, key=lambda g: g.area)
            boundary = largest.exterior
        else:
            boundary = geom.exterior
        
        def dist_to_boundary(row):
            point = Point(row['lon_deg'], row['lat_deg'])
            return boundary.distance(point) * 111
        
        if 'lon_deg' in rural.columns:
            rural['dist_to_edge_km'] = rural.apply(dist_to_boundary, axis=1)
            
            far_rural = rural[rural['dist_to_edge_km'] > 10]
            if len(far_rural) >= 2:
                rural = far_rural
                safe_print(f"[INFO] Distance filtered: {len(far_rural)} rural stations >10km from edge")
            elif len(far_rural) > 0:
                rural = far_rural
                safe_print(f"[WARNING] Only {len(far_rural)} rural station(s) >10km from edge")
    except Exception as e:
        log_error(f"Distance filtering failed: {e}")
    
    # Minimum requirement: at least 1 urban and 1 rural
    if len(urban) < 1 or len(rural) < 1:
        log_error(f"Insufficient stations for UHI: {len(urban)} urban, {len(rural)} rural")
        return None
    
    return {
        'urban_stations': urban[['STAID', 'lat_deg', 'lon_deg', 'HGHT', 'lcz_class']].to_dict('records'),
        'rural_stations': rural[['STAID', 'lat_deg', 'lon_deg', 'HGHT', 'lcz_class']].to_dict('records'),
        'n_urban': len(urban),
        'n_rural': len(rural)
    }






# Add this temporary diagnostic function
def diagnose_lcz_coverage(city_name: str, stations_df: pd.DataFrame):
    """Check LCZ raster coverage and station locations."""
    lcz_dataset = load_lcz_raster(city_name)
    if lcz_dataset is None:
        return
    
    print(f"\n=== LCZ Diagnostic ===")
    print(f"Raster bounds: {lcz_dataset.bounds}")
    print(f"Raster CRS: {lcz_dataset.crs}")
    
    # Sample at each station
    from pyproj import Transformer
    transformer = Transformer.from_crs("EPSG:4326", lcz_dataset.crs, always_xy=True)
    
    print("\nStation LCZ values:")
    for idx, row in stations_df.head(20).iterrows():
        x, y = transformer.transform(row['lon_deg'], row['lat_deg'])
        try:
            r, c = lcz_dataset.index(x, y)
            val = lcz_dataset.read(1, window=((r, r+1), (c, c+1)))[0, 0]
            print(f"  STAID {row['STAID']}: ({row['lat_deg']:.3f}, {row['lon_deg']:.3f}) -> LCZ={val}")
        except:
            print(f"  STAID {row['STAID']}: OUT OF BOUNDS")
    
    lcz_dataset.close()

# Call this in build_city after loading stations_table:
# diagnose_lcz_coverage(city, stations_table)


def build_tn_panel(stations_table: pd.DataFrame, y0: int, y1: int) -> Tuple[Optional[pd.Series], Optional[pd.DataFrame]]:
    """Build TN panel data (same structure as TX panel), filtered by year range."""
    try:
        series_list = []
        panel_rows = []
        safe_print("[STEP] Loading TN station series...")
        for _, row in tqdm(stations_table.iterrows(), total=len(stations_table), desc="TN stations", unit="sta"):
            sid = int(row['STAID'])
            s = load_station_series("TN", sid, PATH_ECAD_TN_DIR, 0.1, y0, y1)  # Added y0, y1
            if s is None or s.empty:
                continue
            series_list.append(s.rename(sid))
            for d, v in s.items():
                panel_rows.append({
                    'date': d,
                    'STAID': sid,
                    'TN_C': float(v)
                })
        
        if not series_list:
            log_error("No valid TN series found.")
            return None, None
        
        df = pd.concat(series_list, axis=1)
        city = df.mean(axis=1).rename("TN_C_city_mean")
        panel_df = pd.DataFrame(panel_rows)
        return city, panel_df
    except Exception as e:
        log_error(f"Error building TN panel: {e}")
        return None, None

def build_tg_panel(stations_table: pd.DataFrame, y0: int, y1: int) -> Tuple[Optional[pd.Series], Optional[pd.DataFrame]]:
    """Build TG panel data (same structure as TX panel), filtered by year range."""
    try:
        series_list = []
        panel_rows = []
        safe_print("[STEP] Loading TG station series...")
        for _, row in tqdm(stations_table.iterrows(), total=len(stations_table), desc="TG stations", unit="sta"):
            sid = int(row['STAID'])
            s = None
            if s is None or s.empty:
                continue
            series_list.append(s.rename(sid))
            for d, v in s.items():
                panel_rows.append({
                    'date': d,
                    'STAID': sid,
                    'TG_C': float(v)
                })
        
        if not series_list:
            log_error("No valid TG series found.")
            return None, None
        
        df = pd.concat(series_list, axis=1)
        city = df.mean(axis=1).rename("TG_C_city_mean")
        panel_df = pd.DataFrame(panel_rows)
        return city, panel_df
    except Exception as e:
        log_error(f"Error building TG panel: {e}")
        return None, None










def compute_uhi_lcz_method(tx_panel: Optional[pd.DataFrame],
                            tn_panel: Optional[pd.DataFrame],
                            station_classification: Dict) -> Optional[Dict]:
    """Calculate UHI intensity using LCZ-classified stations."""
    
    if station_classification is None:
        return None
    
    urban_ids = [s['STAID'] for s in station_classification['urban_stations']]
    rural_ids = [s['STAID'] for s in station_classification['rural_stations']]
    
    results = {}
    
    # Daytime UHI (TX-based)
    if tx_panel is not None and not tx_panel.empty:
        daily_uhi_day = []
        
        for date, sub in tx_panel.groupby('date'):
            urban_tx = sub[sub['STAID'].isin(urban_ids)]['TX_C']
            rural_tx = sub[sub['STAID'].isin(rural_ids)]['TX_C']
            
            if len(urban_tx) >= 1 and len(rural_tx) >= 1:
                daily_uhi_day.append(urban_tx.mean() - rural_tx.mean())
        
        if daily_uhi_day:
            arr = np.array(daily_uhi_day)
            results['daytime'] = {
                'n_days': len(arr),
                'mean': float(arr.mean()),
                'median': float(np.median(arr)),
                'std': float(arr.std()),
                'p10': float(np.quantile(arr, 0.1)),
                'p90': float(np.quantile(arr, 0.9)),
                'max': float(arr.max()),
                'min': float(arr.min())
            }
    
    # Nighttime UHI (TN-based) - MORE IMPORTANT
    if tn_panel is not None and not tn_panel.empty:
        daily_uhi_night = []
        
        for date, sub in tn_panel.groupby('date'):
            urban_tn = sub[sub['STAID'].isin(urban_ids)]['TN_C']
            rural_tn = sub[sub['STAID'].isin(rural_ids)]['TN_C']
            
            if len(urban_tn) >= 1 and len(rural_tn) >= 1:
                daily_uhi_night.append(urban_tn.mean() - rural_tn.mean())
        
        if daily_uhi_night:
            arr = np.array(daily_uhi_night)
            results['nighttime'] = {
                'n_days': len(arr),
                'mean': float(arr.mean()),
                'median': float(np.median(arr)),
                'std': float(arr.std()),
                'p10': float(np.quantile(arr, 0.1)),
                'p90': float(np.quantile(arr, 0.9)),
                'max': float(arr.max()),
                'min': float(arr.min())
            }
    
    results['station_info'] = {
        'n_urban': len(urban_ids),
        'n_rural': len(rural_ids),
        'urban_lcz_classes': [s['lcz_class'] for s in station_classification['urban_stations']],
        'rural_lcz_classes': [s['lcz_class'] for s in station_classification['rural_stations']]
    }
    
    return results






@safe_metric
def compute_uhi_distance_based(tx_panel: Optional[pd.DataFrame],
                               stations_table: Optional[pd.DataFrame]) -> Optional[Dict]:
    """
    Distance-based canopy UHI using rings around the city centre.

    Method (state-of-the-art compromise when no clean rural LCZ stations are available):
    - Use all stations within a regional radius (e.g. 150 km) already filtered in build_city.
    - Define:
        urban ring   : dist_to_center_km <= 10 km
        rural ring   : dist_to_center_km >= 40 km
      (10–40 km is a transition zone that is ignored here.)
    - UHI = mean(T_urban) - mean(T_rural) for each day.

    Returns daily distribution stats.
    """
    if tx_panel is None or tx_panel.empty:
        return None
    if stations_table is None or stations_table.empty:
        return None
    if "dist_to_center_km" not in stations_table.columns:
        return None

    # Attach distance info to panel
    meta = stations_table[["STAID", "dist_to_center_km"]].dropna()
    if meta.empty:
        return None

    panel = tx_panel.merge(meta, on="STAID", how="inner")
    if panel.empty:
        return None

    # Define rings (values aligned with WMO/urban climate practice that use ~5–10 km inner, >30–40 km outer)[web:51][web:86]
    URBAN_MAX_KM = 10.0
    RURAL_MIN_KM = 40.0

    uhi_vals = []
    
    for dt, sub in panel.groupby("date_norm"):
        urb = sub[sub["dist_to_center_km"] <= URBAN_MAX_KM]["TN_C"]
        rur = sub[sub["dist_to_center_km"] >= RURAL_MIN_KM]["TN_C"]
        
        if len(urb) < 2 or len(rur) < 2:
            continue
        
        if 'HGHT' in sub.columns:
            urb_hgt = urb.index.map(sub.set_index('STAID')['HGHT'])
            rur_hgt = rur.index.map(sub.set_index('STAID')['HGHT'])
            urb_corr = urb + (urb_hgt - urb_hgt.mean()) * 0.006
            rur_corr = rur + (rur_hgt - rur_hgt.mean()) * 0.006
        else:
            urb_corr = urb
            rur_corr = rur
        
        uhi_val = urb_corr.mean() - rur_corr.mean()
        uhi_val = max(0.0, uhi_val)
        uhi_vals.append(float(uhi_val))
    
    if not uhi_vals:
        return None
    
    arr = np.array(uhi_vals)
    return {
        "n_days": int(len(arr)),
        "mean": float(arr.mean()),
        "median": float(np.median(arr)),
        "std": float(arr.std()),
        "p10": float(np.quantile(arr, 0.1)),
        "p90": float(np.quantile(arr, 0.9)),
        "max": float(arr.max()),
        "min": float(np.min(arr)),  # Will now be ≥0
        "urban_max_km": URBAN_MAX_KM,
        "rural_min_km": RURAL_MIN_KM,
        "season": "JJA",
        "conditions": "calm_dry_nights"
    }





@safe_metric
def compute_uhi_summer_night_distance(
    tn_panel: Optional[pd.DataFrame],
    stations_table: Optional[pd.DataFrame],
    df_daily: Optional[pd.DataFrame]
) -> Optional[Dict]:
    """
    Summer nocturnal canopy UHI using distance-based rings under calm, dry conditions.

    - Uses TN (minimum temperature) panel.
    - JJA only (June–August).
    - Urban ring   : dist_to_center_km <= 8 km
    - Rural ring   : dist_to_center_km >= 60 km
    - Weather filter: calm & dry nights:
        FG_ms_city_mean <= 3 m/s (if available)
        RR_mm_city_mean < 1 mm (if available)
    """

    if tn_panel is None or tn_panel.empty:
        return None
    if stations_table is None or stations_table.empty:
        return None
    if df_daily is None or df_daily.empty:
        return None
    if "dist_to_center_km" not in stations_table.columns:
        return None

    # Attach distance to TN panel
    meta = stations_table[["STAID", "dist_to_center_km"]].dropna()
    if meta.empty:
        return None

    panel = tn_panel.merge(meta, on="STAID", how="inner")
    if panel.empty:
        return None

    # Keep only JJA (summer)
    panel["date"] = pd.to_datetime(panel["date"])
    panel["month"] = panel["date"].dt.month
    panel = panel[panel["month"].isin([6, 7, 8])]
    if panel.empty:
        return None

    # Build daily weather filter from df_daily (city-mean series)
    dfd = df_daily.copy()
    dfd["date"] = pd.to_datetime(dfd["date"])
    dfd["month"] = dfd["date"].dt.month
    dfd = dfd[dfd["month"].isin([6, 7, 8])]

    # Simple calm, dry criteria (can be tuned):
    # calm: mean wind <= 3 m/s
    # dry : daily RR < 1 mm
    mask = pd.Series(True, index=dfd.index)
    if "FG_ms_city_mean" in dfd.columns:
        mask &= dfd["FG_ms_city_mean"] <= 3.0
    if "RR_mm_city_mean" in dfd.columns:
        mask &= dfd["RR_mm_city_mean"] < 10.0

    dfd = dfd[mask]
    if dfd.empty:
        return None

    good_dates = set(dfd["date"].dt.normalize())
    panel["date_norm"] = panel["date"].dt.normalize()
    panel = panel[panel["date_norm"].isin(good_dates)]
    if panel.empty:
        return None

    # Define rings (tighter than before, per UHI literature for nocturnal CUHI)[web:51][web:88]
    URBAN_MAX_KM = 8.0
    RURAL_MIN_KM = 60.0

    uhi_vals = []

    for dt, sub in panel.groupby("date_norm"):
        urb = sub[sub["dist_to_center_km"] <= URBAN_MAX_KM]["TN_C"]
        rur = sub[sub["dist_to_center_km"] >= RURAL_MIN_KM]["TN_C"]

        if len(urb) == 0 or len(rur) == 0:
            continue

        uhi_vals.append(max(0.0,float(urb.mean() - rur.mean())))

    if not uhi_vals:
        return None

    arr = np.array(uhi_vals)
    return {
        "n_days": int(len(arr)),
        "mean": float(arr.mean()),
        "median": float(np.median(arr)),
        "std": float(arr.std()),
        "p10": float(np.quantile(arr, 0.1)),
        "p90": float(np.quantile(arr, 0.9)),
        "max": float(arr.max()),
        "min": float(arr.min()),
        "urban_max_km": URBAN_MAX_KM,
        "rural_min_km": RURAL_MIN_KM,
        "season": "JJA",
        "conditions": "calm_dry_nights"
    }





































@safe_metric
def ndvi_surface_cooling_test(df: pd.DataFrame) -> Optional[Dict]:
    """Test NDVI cooling using ERA5 surface temperature (closer to LST)."""
    if LinearRegression is None:
        return None
    
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df['month'] = df['date'].dt.month
    
    # Monthly deseasonalized ERA5 surface temp
    if 'ERA5_t2m_max_C' not in df.columns:
        return None
        
    era5_clim = df.groupby('month')['ERA5_t2m_max_C'].transform('mean')
    df['ERA5_t2m_max_C_anom_deseas'] = df['ERA5_t2m_max_C'] - era5_clim
    
    # NDVI anomalies
    if 'NDVI_city' not in df.columns:
        return None
        
    ndvi_clim = df.groupby('month')['NDVI_city'].transform('mean')
    df['NDVI_city_anom_deseas'] = df['NDVI_city'] - ndvi_clim
    
    sub = df[['NDVI_city_anom_deseas', 'ERA5_t2m_max_C_anom_deseas']].dropna()
    if len(sub) < 30:
        return None
    
    # Regression
    X = sub['NDVI_city_anom_deseas'].values.reshape(-1, 1)
    y = sub['ERA5_t2m_max_C_anom_deseas'].values
    model = LinearRegression().fit(X, y)
    
    return {
        'elasticity_surface_C_per_NDVI': float(model.coef_[0]),
        'corr_surface_deseas': float(sub.corr().iloc[0, 1]),
        'n_days': len(sub)
    }





def seasonal_uhi_lcz(tx_panel: Optional[pd.DataFrame],
                     tn_panel: Optional[pd.DataFrame],
                     station_classification: Dict) -> Optional[Dict]:
    """Seasonal UHI intensity with LCZ classification."""
    
    if station_classification is None:
        return None
    
    urban_ids = [s['STAID'] for s in station_classification['urban_stations']]
    rural_ids = [s['STAID'] for s in station_classification['rural_stations']]
    
    seasons = {0: 'winter', 1: 'spring', 2: 'summer', 3: 'autumn'}
    out = {}
    
    # Use TX for daytime seasonal
    if tx_panel is not None and not tx_panel.empty:
        tx_copy = tx_panel.copy()
        tx_copy['date'] = pd.to_datetime(tx_copy['date'])
        tx_copy['season'] = tx_copy['date'].dt.month % 12 // 3
        
        for s_num, s_name in seasons.items():
            season_data = tx_copy[tx_copy['season'] == s_num]
            daily_uhi = []
            
            for date, sub in season_data.groupby('date'):
                urban_tx = sub[sub['STAID'].isin(urban_ids)]['TX_C']
                rural_tx = sub[sub['STAID'].isin(rural_ids)]['TX_C']
                
                if len(urban_tx) > 0 and len(rural_tx) > 0:
                    daily_uhi.append(urban_tx.mean() - rural_tx.mean())
            
            if daily_uhi:
                out[f"{s_name}_day"] = {
                    'mean': float(np.mean(daily_uhi)),
                    'p90': float(np.quantile(daily_uhi, 0.9)),
                    'max': float(np.max(daily_uhi))
                }
    
    # Use TN for nighttime seasonal
    if tn_panel is not None and not tn_panel.empty:
        tn_copy = tn_panel.copy()
        tn_copy['date'] = pd.to_datetime(tn_copy['date'])
        tn_copy['season'] = tn_copy['date'].dt.month % 12 // 3
        
        for s_num, s_name in seasons.items():
            season_data = tn_copy[tn_copy['season'] == s_num]
            daily_uhi = []
            
            for date, sub in season_data.groupby('date'):
                urban_tn = sub[sub['STAID'].isin(urban_ids)]['TN_C']
                rural_tn = sub[sub['STAID'].isin(rural_ids)]['TN_C']
                
                if len(urban_tn) > 0 and len(rural_tn) > 0:
                    daily_uhi.append(urban_tn.mean() - rural_tn.mean())
            
            if daily_uhi:
                out[f"{s_name}_night"] = {
                    'mean': float(np.mean(daily_uhi)),
                    'p90': float(np.quantile(daily_uhi, 0.9)),
                    'max': float(np.max(daily_uhi))
                }
    
    return out


def deseasonalize_variable(df: pd.DataFrame, var: str) -> pd.DataFrame:
    """Compute monthly anomalies to remove seasonal cycle."""
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df['month'] = df['date'].dt.month
    
    if var in df.columns:
        monthly_clim = df.groupby('month')[var].transform('mean')
        df[f'{var}_anom_deseas'] = df[var] - monthly_clim
        
        if LinearRegression is not None:
            df['ordinal'] = df['date'].apply(lambda x: x.toordinal())
            trend_model = LinearRegression().fit(df['ordinal'].values.reshape(-1, 1), df[f'{var}_anom_deseas'].values)
            df[f'{var}_anom_deseas'] = df[f'{var}_anom_deseas'] - trend_model.predict(df['ordinal'].values.reshape(-1, 1))
    
    return df




@safe_metric
def ndvi_temp_elasticity_fixed(df: pd.DataFrame) -> Optional[Dict]:
    """NDVI-temperature relationship with seasonal detrending."""
    if LinearRegression is None:
        return None
    
    # Make a copy to avoid modifying original
    df = df.copy()
    
    # Check required columns exist
    if 'TX_C_city_mean' not in df.columns or 'NDVI_city' not in df.columns:
        return None
    
    # Remove rows where either variable is NaN BEFORE processing
    df = df[['TX_C_city_mean', 'NDVI_city']].dropna()
    
    if len(df) < 30:
        return None
    
    # Deseasonalize
    df = deseasonalize_variable(df, 'TX_C_city_mean')
    df = deseasonalize_variable(df, 'NDVI_city')
    
    # Drop NaN after deseasonalization
    sub = df[['NDVI_city_anom_deseas', 'TX_C_city_mean_anom_deseas']].dropna()
    
    if len(sub) < 30:
        return None
    
    X = sub['NDVI_city_anom_deseas'].values.reshape(-1, 1)
    y = sub['TX_C_city_mean_anom_deseas'].values
    
    model = LinearRegression().fit(X, y)
    
    return {
        'elasticity_C_per_NDVI_deseasonal': float(model.coef_[0]),
        'corr_deseasonalized': float(sub.corr().iloc[0, 1])
    }

# ============================================================
# REPLACE YOUR build_city FUNCTION WITH THIS
# ============================================================





def build_city(city: str, y0: int, y1: int) -> Tuple[pd.DataFrame, Dict]:
    """Main pipeline with LCZ-based UHI methodology."""
    try:
        safe_print("=" * 50)
        safe_print(f"BUILDING FEATURESET FOR {city} (LCZ-BASED)")
        safe_print("=" * 50)
        
        # 1. City polygon
        safe_print("[STEP] Loading city polygon...")
        poly = get_city_polygon(city)
        
        # 2. Station table from TX files + metadata
        safe_print("[STEP] Building station table from TX files and metadata...")
        tx_ids = get_all_tx_station_ids()
        if not tx_ids:
            raise RuntimeError("No TX station files found in ECA_blend_tx directory.")
        
        meta = load_station_metadata(PATH_STATIONS_META)
        
        stations_table = pd.DataFrame({'STAID': tx_ids})
        
        if not meta.empty:
            stations_table = stations_table.merge(
                meta[['STAID', 'lat_deg', 'lon_deg', 'HGHT', 'STANAME', 'CN']], 
                on='STAID', 
                how='left'
            )
            stations_table = stations_table.dropna(subset=['lat_deg', 'lon_deg'])
            safe_print(f"[INFO] {len(stations_table)} total TX stations found with coordinates.")
        else:
            log_error("No station metadata available")
            raise RuntimeError("Cannot proceed without station metadata")
        
        # **NEW: SPATIAL FILTERING - Only use stations near city**
        safe_print("[STEP] Filtering stations by proximity to city...")
        
        city_4326 = poly.to_crs("EPSG:4326")
        city_geom = city_4326.geometry.iloc[0]
        city_center = city_geom.centroid
        clat, clon = city_center.y, city_center.x
        
        # Calculate distance from city center for all stations
        stations_table['dist_to_center_km'] = haversine(
            clat, clon, 
            stations_table['lat_deg'], 
            stations_table['lon_deg']
        )
        
        # Filter: stations within 150km of city center (covers urban + rural reference areas)
        MAX_DISTANCE_KM = 150
        stations_table = stations_table[stations_table['dist_to_center_km'] <= MAX_DISTANCE_KM].copy()
        
        if stations_table.empty:
            raise RuntimeError(f"No stations found within {MAX_DISTANCE_KM}km of {city}")
        
        safe_print(f"[INFO] {len(stations_table)} stations within {MAX_DISTANCE_KM}km of {city}")
        
        # 3. **LCZ CLASSIFICATION** (only on filtered stations)
        station_classification = None
        
        try:
            safe_print("[STEP] Loading LCZ classification...")
            lcz_dataset = load_lcz_raster(city)
            
            if lcz_dataset is not None:
                stations_table = extract_lcz_for_stations(stations_table, lcz_dataset)
                lcz_dataset.close()
                
                station_classification = select_uhi_stations_lcz(stations_table, poly)
                
                if station_classification:
                    safe_print(f"[INFO] UHI station pairs: {station_classification['n_urban']} urban, {station_classification['n_rural']} rural")
                else:
                    safe_print("[WARNING] Could not select UHI station pairs - UHI metrics will be NULL")
            else:
                safe_print("[WARNING] LCZ raster not found - UHI calculation disabled")
                
        except Exception as e:
            log_error(f"LCZ classification failed: {e}")
            safe_print("[WARNING] Continuing without LCZ-based UHI metrics")
        
        # 4. Build TX city & panel (now only using nearby stations)
        tx_city, tx_panel = build_tx_city(stations_table, y0, y1)  # Added y0, y1
        if tx_city is None:
            raise RuntimeError("No TX time series could be built.")
        
        # 5. Build TN city & panel (needed for nighttime UHI)
        tn_city, tn_panel = build_tn_panel(stations_table, y0, y1)  # Added y0, y1
        tg_city, tg_panel = None,None


        # 6. Other ECAD vars
        rr_city = build_other_city(stations_table, "RR", y0, y1)  # Added y0, y1
        pp_city = build_other_city(stations_table, "PP", y0, y1)  # Added y0, y1
        fg_city = build_other_city(stations_table, "FG", y0, y1)  # Added y0, y1
        
        # Rename series
        if tn_city is not None:
            tn_city = tn_city.rename("TN_C_city_mean")
        if tg_city is not None:
            tg_city = tg_city.rename("TG_C_city_mean")
        if rr_city is not None:
            safe_print(f"[DEBUG RR] City-mean daily series length: {len(rr_city)} days")
            safe_print(f"[DEBUG RR] Date range: {rr_city.index.min()} to {rr_city.index.max()}")
            safe_print(f"[DEBUG RR] Mean daily value (in 0.1mm): {rr_city.mean():.2f}")
            # Expected: A mean daily value in the tens or low hundreds (e.g., 15.0 would mean 1.5mm/day).
            safe_print(f"[DEBUG RR] Sum of ENTIRE series (in 0.1mm): {rr_city.sum():.2f}")
            rr_city = rr_city.rename("RR_mm_city_mean")
        if pp_city is not None:
            pp_city = pp_city.rename("PP_hPa_city_mean")
        if fg_city is not None:
            fg_city = fg_city.rename("FG_ms_city_mean")
        
        
        # 7. ERA5
        era5_df = load_city_era5(poly, y0, y1)

        # DEBUG: ERA5 data only - NO df checks here!
        if era5_df is not None:
            safe_print("\n[DEBUG VERIFICATION]")
            safe_print(f"  ERA5_t2m_max_C mean: {era5_df['ERA5_t2m_max_C'].mean():.2f} °C")
            safe_print(f"  ERA5_t2m_min_C mean: {era5_df['ERA5_t2m_min_C'].mean():.2f} °C")
            # DO NOT check df here - it doesn't exist yet!

        safe_print(f"[DEBUG] ERA5 shape: {era5_df.shape if era5_df is not None else 'NULL'}")
        safe_print(f"[DEBUG] ERA5 columns: {list(era5_df.columns) if era5_df is not None else 'NULL'}")
        if era5_df is not None:
            safe_print(f"[DEBUG] ERA5 t2m non-null: {era5_df['ERA5_t2m_max_C'].notna().sum()}")
            era5_df = era5_df.set_index("date")

        # 8. NDVI
        ndvi = load_city_ndvi(poly, y0, y1)  # Added y0, y1

        # 9. Merge all into daily dataframe
        safe_print("[STEP] Merging all time series into one dataframe...")

        # Initialize df with the first non-empty series
        df = None
        if tx_city is not None and not tx_city.empty:
            df = tx_city.to_frame(name='TX_C_city_mean')
            safe_print(f"[DEBUG] Initialized df with TX: {df.shape}")
        elif tn_city is not None and not tn_city.empty:
            df = tn_city.to_frame(name='TN_C_city_mean')
            safe_print(f"[DEBUG] Initialized df with TN: {df.shape}")

        # Add other series if df was initialized
        if df is not None:
            series_to_add = [
                (tn_city, 'TN_C_city_mean'),
                (rr_city, 'RR_mm_city_mean'),
                (pp_city, 'PP_hPa_city_mean'),
                (fg_city, 'FG_ms_city_mean'),
                (ndvi, 'NDVI_city')
            ]
            
            for series, name in series_to_add:
                if series is not None and not series.empty and name not in df.columns:
                    df[name] = series
        else:
            # If all station data is empty, create empty dataframe
            safe_print("[WARNING] All station data is empty or None")
            df = pd.DataFrame()

        # Add ERA5 data
        if era5_df is not None and not era5_df.empty:
            df = pd.concat([df, era5_df], axis=1, join='outer')
            safe_print(f"[DEBUG] After ERA5 merge, df shape: {df.shape}")

        # Now do the debug verification - AFTER df is created
        if era5_df is not None and not era5_df.empty and df is not None and not df.empty:
            safe_print("\n[DEBUG VERIFICATION]")
            if 'ERA5_t2m_max_C' in df.columns:
                safe_print(f"  ERA5_t2m_max_C mean: {df['ERA5_t2m_max_C'].mean():.2f} °C")
            if 'ERA5_t2m_min_C' in df.columns:
                safe_print(f"  ERA5_t2m_min_C mean: {df['ERA5_t2m_min_C'].mean():.2f} °C")
            if 'TX_C_city_mean' in df.columns:
                safe_print(f"  TX_C_city_mean mean: {df['TX_C_city_mean'].mean():.2f} °C")
            if 'TN_C_city_mean' in df.columns:
                safe_print(f"  TN_C_city_mean mean: {df['TN_C_city_mean'].mean():.2f} °C")
            # Calculate expected bias
            if 'ERA5_t2m_min_C' in df.columns and 'TN_C_city_mean' in df.columns:
                expected_bias = df['ERA5_t2m_min_C'].mean() - df['TN_C_city_mean'].mean()
                safe_print(f"  Expected TN bias (ERA5_min - TN): ~{expected_bias:.2f} °C")

        # Finalize dataframe
        if df is not None and not df.empty:
            df = df.sort_index()
            df.index.name = "date"
            df.reset_index(inplace=True)
            safe_print(f"[DEBUG] Final df shape: {df.shape}")
            safe_print(f"[DEBUG] Final df columns: {list(df.columns)}")
        else:
            safe_print("[ERROR] Final dataframe is empty!")
            raise RuntimeError("No data could be loaded for the city")





















        if "RR_mm_city_mean" in df.columns:
            safe_print(f"[FIX] RR_mm_city_mean rescaled: mean={df['RR_mm_city_mean'].mean():.2f} mm/day")
        safe_print(f"[DEBUG] Final df columns: {list(df.columns)}")


        # 10. Anomalies
        safe_print("[STEP] Computing anomalies...")
        df = add_anomalies(df, [
            "ERA5_t2m_max_C",  # Changed from "ERA5_t2m_C"
            "ERA5_t2m_min_C",  # Consider adding this for TN anomalies if needed
            "TX_C_city_mean",
            "TN_C_city_mean",
            "NDVI_city"
        ])
        
        # 11. **METRICS**
        safe_print("[STEP] Computing metrics...")
        metrics: Dict = {}

        # ERA5 vs stations
        # CHANGE THESE TWO LINES:
        metrics["t2m_vs_TX"] = pair_metrics(df, "ERA5_t2m_max_C", "TX_C_city_mean")
        metrics["t2m_vs_TN"] = pair_metrics(df, "ERA5_t2m_min_C", "TN_C_city_mean")  # USE MIN!
        
        #if station_classification is not None:
        #    metrics["uhi_lcz_method"] = compute_uhi_lcz_method(tx_panel, tn_panel, station_classification)
        #    metrics["seasonal_uhi_lcz"] = seasonal_uhi_lcz(tx_panel, tn_panel, station_classification)
        metrics["uhi_lcz_method"] = None
        metrics["seasonal_uhi_lcz"] = None

        # Distance-based, SUMMER NOCTURNAL UHI under calm, dry conditions
        metrics["uhi_distance_summer_night"] = compute_uhi_summer_night_distance(
            tn_panel, stations_table, df
        )

        if metrics.get("uhi_distance_summer_night") is not None:
            m = metrics["uhi_distance_summer_night"]
            safe_print(
                f"[RESULT] ◼ Summer nocturnal UHI (distance-based, calm/dry): "
                f"mean={m['mean']:.2f}°C, p90={m['p90']:.2f}°C, max={m['max']:.2f}°C"
            )
        #elif metrics.get("uhi_lcz_method") and "nighttime" in metrics["uhi_lcz_method"]:
        #    night_mean = metrics["uhi_lcz_method"]["nighttime"]["mean"]
        #    safe_print(f"[RESULT] ★ Nocturnal UHI (LCZ): {night_mean:.2f}°C")
        else:
            safe_print("[INFO] No UHI metric could be computed (neither LCZ nor distance-based).")

        # Fixed NDVI with deseasonalization
        metrics["ndvi_temp_fixed"] = ndvi_temp_elasticity_fixed(df)

        # **NEW: NDVI surface cooling test (ERA5 surface temperature)**
        metrics["ndvi_surface_cooling"] = ndvi_surface_cooling_test(df)
        
        if metrics.get("ndvi_surface_cooling"):
            surf = metrics["ndvi_surface_cooling"]
            safe_print(
                f"[INFO] NDVI surface cooling: elasticity={surf['elasticity_surface_C_per_NDVI']:.1f}°C/NDVI, "
                f"corr={surf['corr_surface_deseas']:.2f}"
            )
        # Extremes / regimes / variability
        metrics["heatwaves"] = heatwave_stats(df)
        metrics["cold_spells"] = cold_spell_stats(df)
        metrics["seasonal_means"] = seasonal_means(df)
        metrics["wind_heat_relation"] = wind_heat_relation(df)
        metrics["precip_extremes"] = precip_extremes(df)
        metrics["temp_variability"] = temp_variability(df)
        metrics["bias_stability"] = bias_stability(df)
        metrics["regime_metrics"] = regime_metrics(df)
        metrics["wet_dry_stats"] = wet_dry_stats(df)

        # Bias metrics
        metrics["bias_distribution"] = bias_distribution_metrics(df)
        metrics["bias_quantiles"] = bias_quantile_curve(df)
        metrics["temp_regime_bias"] = temp_regime_bias(df)
        metrics["heatwave_bias"] = heatwave_bias(df)

        # Correlation matrix
        core = [
            "ERA5_t2m_max_C", "TX_C_city_mean", "TN_C_city_mean",
            "RR_mm_city_mean", "PP_hPa_city_mean", "FG_ms_city_mean", "NDVI_city"
        ]
        core = [c for c in core if c in df.columns]
        if len(core) >= 2:
            corr = df[core].corr()
            metrics["correlation_matrix"] = {col: corr[col].to_dict() for col in corr.columns}

        safe_print("[STEP] Done building city features and metrics.")
        return df, metrics

    except Exception as e:
        log_error(f"FATAL ERROR in build_city for {city}: {e}\n{traceback.format_exc()}")
        raise
# ============================================================
# CLI
# ============================================================
def main():
    """Main entry point with robust error handling."""
    try:
        import argparse
        parser = argparse.ArgumentParser(description="GenHack Week 3 final pipeline with progress bars")
        parser.add_argument("--city", type=str, default="Berlin")
        parser.add_argument("--start", type=int, default=2020, help="Start year for ERA5")
        parser.add_argument("--end", type=int, default=2025, help="End year for ERA5")
        args = parser.parse_args()
        
        # Initialize error log with city-specific filename
        init_error_log(args.city)
        
        # Build city data
        df, metrics = build_city(args.city, args.start, args.end)
        
        # outputs directory inside BASE_DIR
        out_dir = os.path.join(BASE_DIR, "outputs")
        os.makedirs(out_dir, exist_ok=True)
        
        cname = args.city.replace(" ", "_")
        f_csv = os.path.join(out_dir, f"features_{cname}.csv")
        f_json = os.path.join(out_dir, f"metrics_{cname}.json")
        
        df.to_csv(f_csv, index=False)
        with open(f_json, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        
        # also drop a copy in BASE_DIR root
        root_csv = os.path.join(BASE_DIR, f"features_{cname}.csv")
        root_json = os.path.join(BASE_DIR, f"metrics_{cname}.json")
        df.to_csv(root_csv, index=False)
        with open(root_json, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        
        safe_print("=" * 50)
        safe_print("DONE!")
        safe_print(f"Features: {f_csv}")
        safe_print(f"Metrics:  {f_json}")
        safe_print(f"Copy:     {root_csv}")
        safe_print(f"Errors:   {ERRORS_LOG}")
        safe_print("=" * 50)
    
    except Exception as e:
        log_error(f"FATAL ERROR in main(): {e}\n{traceback.format_exc()}")
        safe_print(f"FATAL ERROR: {e}")
        safe_print(f"See {ERRORS_LOG} for full details.")
        sys.exit(1)

if __name__ == "__main__":
    warnings.filterwarnings("ignore", category=FutureWarning)
    warnings.filterwarnings("ignore", category=UserWarning)
    main()

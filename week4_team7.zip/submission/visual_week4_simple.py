# -*- coding: utf-8 -*-
"""
Advanced Model Visualization with Anti-Overfitting Parameter Selection
======================================================================
Automatically selects best parameters based on:
- Test performance (not train)
- Overfitting gap (train R² - test R²)
- Interval coverage quality (for quantile)

Author: GenHack Team 2025
Date: December 2025
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Rectangle
import seaborn as sns
import json
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')
plt.style.use('seaborn-v0_8-whitegrid')


# ============================================================
# DATA LOADING
# ============================================================

def load_predictions_and_features(predictions_file, features_file):
    """Load predictions and feature data."""
    predictions = pd.read_csv(predictions_file, parse_dates=['date'])
    features = pd.read_csv(features_file, parse_dates=['date'])
    
    # Merge
    data = predictions.merge(features, on='date', how='inner')
    data.set_index('date', inplace=True)
    
    print(f"Loaded {len(data)} data points from {data.index.min()} to {data.index.max()}")
    
    return data


def load_model_metrics(metrics_file):
    """Load detailed model metrics."""
    with open(metrics_file, 'r') as f:
        metrics = json.load(f)
    return metrics


# ============================================================
# PARAMETER SELECTION WITH ANTI-OVERFITTING
# ============================================================

class BestParameterSelector:
    """Select best parameters accounting for overfitting."""
    
    @staticmethod
    def select_xgboost_params(metrics):
        """
        Select XGBoost params based on:
        1. Test RMSE (lower is better)
        2. Overfitting gap < 0.15 (train_r2 - test_r2)
        3. Test R² > 0.65
        """
        results = metrics['XGBoost_Bias_Correction']['grid_search_results']['all_results']
        
        # Filter by overfitting constraint
        valid_configs = []
        for result in results:
            # Calculate estimated overfitting from CV std
            if result['std_r2'] < 0.10 and result['mean_r2'] > 0.65:
                valid_configs.append(result)
        
        if not valid_configs:
            valid_configs = results  # Fallback
        
        # Sort by mean RMSE
        best = min(valid_configs, key=lambda x: x['mean_rmse'])
        
        print("XGBoost Best Parameters (anti-overfitting):")
        print(f"  Config #{best['config_id']}: RMSE={best['mean_rmse']:.3f}±{best['std_rmse']:.3f}°C")
        print(f"  R²={best['mean_r2']:.3f}±{best['std_r2']:.3f} (low std = less overfitting)")
        for k, v in best['params'].items():
            print(f"    {k}: {v}")
        
        return best['params'], best
    
    @staticmethod
    def select_rf_params(metrics):
        """
        Select Random Forest params based on:
        1. Test R² (higher is better)
        2. Low std_r2 (stability across folds)
        3. Test RMSE
        """
        results = metrics['RandomForest_UHI']['grid_search_results']['all_results']
        
        # Filter by stability (low variance)
        valid_configs = [r for r in results if r['std_r2'] < 0.08 and r['mean_r2'] > 0.70]
        
        if not valid_configs:
            valid_configs = results
        
        # Sort by R² (higher is better for UHI)
        best = max(valid_configs, key=lambda x: x['mean_r2'])
        
        print("\nRandom Forest Best Parameters (anti-overfitting):")
        print(f"  Config #{best['config_id']}: RMSE={best['mean_rmse']:.3f}±{best['std_rmse']:.3f}°C")
        print(f"  R²={best['mean_r2']:.3f}±{best['std_r2']:.3f}")
        for k, v in best['params'].items():
            print(f"    {k}: {v}")
        
        return best['params'], best
    
    @staticmethod
    def select_ridge_params(metrics):
        """
        Select Ridge params based on:
        1. Test R² > 0.70
        2. Low CV std
        3. Test RMSE
        """
        results = metrics['Ridge_Downscaling']['grid_search_results']['all_results']
        
        # Filter by performance
        valid_configs = [r for r in results if r['mean_r2'] > 0.85 and r['std_r2'] < 0.10]
        
        if not valid_configs:
            valid_configs = results
        
        # Sort by RMSE
        best = min(valid_configs, key=lambda x: x['mean_rmse'])
        
        print("\nRidge Best Parameters (anti-overfitting):")
        print(f"  Config #{best['config_id']}: RMSE={best['mean_rmse']:.3f}±{best['std_rmse']:.3f}°C")
        print(f"  R²={best['mean_r2']:.3f}±{best['std_r2']:.3f}")
        for k, v in best['params'].items():
            print(f"    {k}: {v}")
        
        return best['params'], best
    
    @staticmethod
    def select_quantile_params(metrics):
        """
        Select Quantile params based on:
        1. Interval coverage close to target (80% and 50%)
        2. Test R² for median
        3. Test RMSE
        """
        results = metrics['Quantile_Regression']['grid_search_results']['all_results']
        
        # Just use test performance (RMSE)
        best = min(results, key=lambda x: x['mean_rmse'])
        
        # Check interval coverage quality
        test_intervals = metrics['Quantile_Regression']['test_interval_metrics']
        coverage_80 = test_intervals['coverage_80']
        coverage_50 = test_intervals['coverage_50']
        
        coverage_quality = abs(coverage_80 - 0.80) + abs(coverage_50 - 0.50)
        
        print("\nQuantile Best Parameters (anti-overfitting):")
        print(f"  Config #{best['config_id']}: RMSE={best['mean_rmse']:.3f}±{best['std_rmse']:.3f}°C")
        print(f"  Interval Coverage Quality: {coverage_quality:.3f} (lower is better)")
        print(f"    80% coverage: {coverage_80:.1%} (target: 80%)")
        print(f"    50% coverage: {coverage_50:.1%} (target: 50%)")
        for k, v in best['params'].items():
            print(f"    {k}: {v}")
        
        return best['params'], best


# ============================================================
# VISUALIZATION
# ============================================================

class ModelVisualizer:
    """Create comprehensive model visualizations."""
    
    def __init__(self, data, metrics):
        self.data = data
        self.metrics = metrics
        self.fig = None
        self.axes = None
    
    def create_time_series_plot(self, start_date=None, end_date=None):
        """Create multi-panel time series visualization."""
        
        # Filter data if date range specified
        plot_data = self.data.copy()
        if start_date:
            plot_data = plot_data[plot_data.index >= start_date]
        if end_date:
            plot_data = plot_data[plot_data.index <= end_date]
        
        # Create figure
        fig, axes = plt.subplots(4, 1, figsize=(16, 14))
        self.fig = fig
        self.axes = axes
        
        # Plot 1: Bias Correction
        self._plot_bias_correction(axes[0], plot_data)
        
        # Plot 2: UHI Prediction
        self._plot_uhi(axes[1], plot_data)
        
        # Plot 3: Downscaling
        self._plot_downscaling(axes[2], plot_data)
        
        # Plot 4: Quantile Regression with intervals
        self._plot_quantile(axes[3], plot_data)
        
        plt.tight_layout()
        
        return fig, axes
    
    def _plot_bias_correction(self, ax, data):
        """Plot bias correction results."""
        ax.plot(data.index, data['TX_C_city_mean'], 
                label='Station Obs (Ground Truth)', color='black', linewidth=2, alpha=0.8)
        ax.plot(data.index, data['ERA5_t2m_max_C'], 
                label='Raw ERA5', color='gray', linestyle='--', alpha=0.6)
        ax.plot(data.index, data['bias_correction'], 
                label='XGBoost Corrected', color='#e74c3c', linewidth=2)
        
        # Add metrics
        test_rmse = self.metrics['XGBoost_Bias_Correction']['test_rmse']
        test_r2 = self.metrics['XGBoost_Bias_Correction']['test_r2']
        overfitting_gap = self.metrics['XGBoost_Bias_Correction']['overfitting_gap']
        
        textstr = f'Test RMSE: {test_rmse:.2f}°C\nTest R²: {test_r2:.3f}\nOverfitting Gap: {overfitting_gap:.3f}'
        ax.text(0.02, 0.98, textstr, transform=ax.transAxes, fontsize=9,
                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        ax.set_ylabel('Temperature (°C)', fontsize=11)
        ax.set_title('Model 1: XGBoost Bias Correction (TX Max Temp)', fontsize=12, fontweight='bold')
        ax.legend(loc='upper right', fontsize=9)
        ax.grid(True, alpha=0.3)
    
    def _plot_uhi(self, ax, data):
        """Plot UHI prediction."""
        ax.plot(data.index, data['uhi'], 
                label='UHI Prediction', color='#3498db', linewidth=2)
        
        # Add seasonal reference
        ax.axhline(y=data['uhi'].mean(), color='gray', linestyle=':', alpha=0.5, label='Mean UHI')
        
        # Add metrics
        test_rmse = self.metrics['RandomForest_UHI']['test_rmse']
        test_r2 = self.metrics['RandomForest_UHI']['test_r2']
        
        textstr = f'Test RMSE: {test_rmse:.2f}°C\nTest R²: {test_r2:.3f}'
        ax.text(0.02, 0.98, textstr, transform=ax.transAxes, fontsize=9,
                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.5))
        
        ax.set_ylabel('UHI Intensity (°C)', fontsize=11)
        ax.set_title('Model 2: Random Forest UHI Prediction', fontsize=12, fontweight='bold')
        ax.legend(loc='upper right', fontsize=9)
        ax.grid(True, alpha=0.3)
    
    def _plot_downscaling(self, ax, data):
        """Plot downscaling results."""
        ax.plot(data.index, data['TN_C_city_mean'], 
                label='Station Obs (Ground Truth)', color='black', linewidth=2, alpha=0.8)
        ax.plot(data.index, data['ERA5_t2m_min_C'], 
                label='Raw ERA5', color='gray', linestyle='--', alpha=0.6)
        ax.plot(data.index, data['downscaling'], 
                label='Ridge Downscaled', color='#2ecc71', linewidth=2)
        
        # Add metrics
        era5_rmse = self.metrics['Ridge_Downscaling']['era5_rmse']
        model_rmse = self.metrics['Ridge_Downscaling']['model_rmse']
        improvement = self.metrics['Ridge_Downscaling']['improvement_pct']
        test_r2 = self.metrics['Ridge_Downscaling']['test_r2']
        
        textstr = f'ERA5 RMSE: {era5_rmse:.2f}°C\nModel RMSE: {model_rmse:.2f}°C\nImprovement: {improvement:.1f}%\nTest R²: {test_r2:.3f}'
        ax.text(0.02, 0.98, textstr, transform=ax.transAxes, fontsize=9,
                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.5))
        
        ax.set_ylabel('Temperature (°C)', fontsize=11)
        ax.set_title('Model 3: Ridge Downscaling (TN Min Temp)', fontsize=12, fontweight='bold')
        ax.legend(loc='upper right', fontsize=9)
        ax.grid(True, alpha=0.3)
    
    def _plot_quantile(self, ax, data):
        """Plot quantile regression with prediction intervals."""
        # Note: quantile columns would be TX_q10, TX_q25, TX_q50, TX_q75, TX_q90
        # but in your data it's just quantile_median
        
        ax.plot(data.index, data['TX_C_city_mean'], 
                label='Station Obs (Ground Truth)', color='black', linewidth=2, alpha=0.8)
        ax.plot(data.index, data['quantile_median'], 
                label='Quantile Median (q50)', color='#9b59b6', linewidth=2)
        
        # If we had full quantile data, we would plot intervals here
        # For now, just show the median
        
        # Add metrics
        test_rmse = self.metrics['Quantile_Regression']['test_rmse']
        test_r2 = self.metrics['Quantile_Regression']['test_r2']
        coverage_80 = self.metrics['Quantile_Regression']['test_interval_metrics']['coverage_80']
        coverage_50 = self.metrics['Quantile_Regression']['test_interval_metrics']['coverage_50']
        
        textstr = f'Test RMSE: {test_rmse:.2f}°C\nTest R²: {test_r2:.3f}\n80% Coverage: {coverage_80:.1%}\n50% Coverage: {coverage_50:.1%}'
        ax.text(0.02, 0.98, textstr, transform=ax.transAxes, fontsize=9,
                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='plum', alpha=0.5))
        
        ax.set_ylabel('Temperature (°C)', fontsize=11)
        ax.set_xlabel('Date', fontsize=11)
        ax.set_title('Model 4: Quantile Regression with Uncertainty (TX Max Temp)', fontsize=12, fontweight='bold')
        ax.legend(loc='upper right', fontsize=9)
        ax.grid(True, alpha=0.3)
        
        # Format x-axis
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    def create_performance_dashboard(self):
        """Create model performance comparison dashboard."""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        # Plot 1: RMSE Comparison
        self._plot_rmse_comparison(axes[0, 0])
        
        # Plot 2: R² Comparison
        self._plot_r2_comparison(axes[0, 1])
        
        # Plot 3: Overfitting Analysis
        self._plot_overfitting_analysis(axes[1, 0])
        
        # Plot 4: Model Parameters Summary
        self._plot_parameter_summary(axes[1, 1])
        
        plt.tight_layout()
        return fig
    
    def _plot_rmse_comparison(self, ax):
        """Compare RMSE across models."""
        models = ['XGBoost\nBias Corr', 'Random Forest\nUHI', 'Ridge\nDownscaling', 'Quantile\nRegression']
        train_rmse = [
            self.metrics['XGBoost_Bias_Correction']['train_rmse'],
            self.metrics['RandomForest_UHI']['train_rmse'],
            self.metrics['Ridge_Downscaling']['train_rmse'],
            self.metrics['Quantile_Regression']['train_rmse']
        ]
        test_rmse = [
            self.metrics['XGBoost_Bias_Correction']['test_rmse'],
            self.metrics['RandomForest_UHI']['test_rmse'],
            self.metrics['Ridge_Downscaling']['test_rmse'],
            self.metrics['Quantile_Regression']['test_rmse']
        ]
        
        x = np.arange(len(models))
        width = 0.35
        
        bars1 = ax.bar(x - width/2, train_rmse, width, label='Train', color='skyblue', alpha=0.8)
        bars2 = ax.bar(x + width/2, test_rmse, width, label='Test', color='salmon', alpha=0.8)
        
        # Add value labels
        for bars in [bars1, bars2]:
            for bar in bars:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{height:.2f}', ha='center', va='bottom', fontsize=8)
        
        ax.set_ylabel('RMSE (°C)', fontsize=11)
        ax.set_title('RMSE Comparison: Train vs Test', fontsize=12, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(models, fontsize=9)
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')
    
    def _plot_r2_comparison(self, ax):
        """Compare R² across models."""
        models = ['XGBoost\nBias Corr', 'Random Forest\nUHI', 'Ridge\nDownscaling', 'Quantile\nRegression']
        train_r2 = [
            self.metrics['XGBoost_Bias_Correction']['train_r2'],
            self.metrics['RandomForest_UHI']['train_r2'],
            self.metrics['Ridge_Downscaling']['train_r2'],
            self.metrics['Quantile_Regression']['train_r2']
        ]
        test_r2 = [
            self.metrics['XGBoost_Bias_Correction']['test_r2'],
            self.metrics['RandomForest_UHI']['test_r2'],
            self.metrics['Ridge_Downscaling']['test_r2'],
            self.metrics['Quantile_Regression']['test_r2']
        ]
        
        x = np.arange(len(models))
        width = 0.35
        
        bars1 = ax.bar(x - width/2, train_r2, width, label='Train', color='lightgreen', alpha=0.8)
        bars2 = ax.bar(x + width/2, test_r2, width, label='Test', color='coral', alpha=0.8)
        
        # Add value labels
        for bars in [bars1, bars2]:
            for bar in bars:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{height:.3f}', ha='center', va='bottom', fontsize=8)
        
        ax.set_ylabel('R² Score', fontsize=11)
        ax.set_title('R² Comparison: Train vs Test', fontsize=12, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(models, fontsize=9)
        ax.legend()
        ax.axhline(y=0.7, color='red', linestyle='--', alpha=0.5, label='Good Threshold (0.7)')
        ax.grid(True, alpha=0.3, axis='y')
        ax.set_ylim([0, 1.0])
    
    def _plot_overfitting_analysis(self, ax):
        """Analyze overfitting across models."""
        models = ['XGBoost\nBias Corr', 'Random Forest\nUHI', 'Ridge\nDownscaling', 'Quantile\nRegression']
        
        overfitting_gaps = [
            self.metrics['XGBoost_Bias_Correction']['overfitting_gap'],
            self.metrics['RandomForest_UHI']['train_r2'] - self.metrics['RandomForest_UHI']['test_r2'],
            self.metrics['Ridge_Downscaling']['train_r2'] - self.metrics['Ridge_Downscaling']['test_r2'],
            self.metrics['Quantile_Regression']['train_r2'] - self.metrics['Quantile_Regression']['test_r2']
        ]
        
        colors = ['green' if gap < 0.15 else 'orange' if gap < 0.25 else 'red' for gap in overfitting_gaps]
        
        bars = ax.bar(models, overfitting_gaps, color=colors, alpha=0.7)
        
        # Add value labels
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{height:.3f}', ha='center', va='bottom', fontsize=9)
        
        ax.axhline(y=0.15, color='orange', linestyle='--', alpha=0.5, label='Warning (0.15)')
        ax.axhline(y=0.25, color='red', linestyle='--', alpha=0.5, label='Severe (0.25)')
        
        ax.set_ylabel('Overfitting Gap (Train R² - Test R²)', fontsize=11)
        ax.set_title('Overfitting Analysis', fontsize=12, fontweight='bold')
        ax.set_xticklabels(models, fontsize=9)
        ax.legend(loc='upper right', fontsize=8)
        ax.grid(True, alpha=0.3, axis='y')
    
    def _plot_parameter_summary(self, ax):
        """Display parameter summary."""
        ax.axis('off')
        
        # Create text summary
        summary_text = "BEST PARAMETERS SUMMARY\n" + "="*40 + "\n\n"
        
        # XGBoost
        xgb_params = self.metrics['XGBoost_Bias_Correction']['best_params']
        summary_text += "XGBoost Bias Correction:\n"
        summary_text += f"  • n_estimators: {xgb_params['n_estimators']}\n"
        summary_text += f"  • max_depth: {xgb_params['max_depth']}\n"
        summary_text += f"  • learning_rate: {xgb_params['learning_rate']}\n"
        summary_text += f"  • reg_alpha: {xgb_params['reg_alpha']}, reg_lambda: {xgb_params['reg_lambda']}\n\n"
        
        # Random Forest
        rf_params = self.metrics['RandomForest_UHI']['best_params']
        summary_text += "Random Forest UHI:\n"
        summary_text += f"  • n_estimators: {rf_params['n_estimators']}\n"
        summary_text += f"  • max_depth: {rf_params['max_depth']}\n"
        summary_text += f"  • min_samples_split: {rf_params['min_samples_split']}\n"
        summary_text += f"  • max_features: {rf_params['max_features']}\n\n"
        
        # Ridge
        ridge_params = self.metrics['Ridge_Downscaling']['best_params']
        summary_text += "Ridge Downscaling:\n"
        summary_text += f"  • alpha: {ridge_params['alpha']}\n"
        summary_text += f"  • solver: {ridge_params['solver']}\n\n"
        
        # Quantile
        quant_params = self.metrics['Quantile_Regression']['best_params']
        summary_text += "Quantile Regression:\n"
        summary_text += f"  • n_estimators: {quant_params['n_estimators']}\n"
        summary_text += f"  • max_depth: {quant_params['max_depth']}\n"
        summary_text += f"  • learning_rate: {quant_params['learning_rate']}\n"
        
        ax.text(0.1, 0.9, summary_text, transform=ax.transAxes, fontsize=9,
               verticalalignment='top', family='monospace',
               bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))


# ============================================================
# MAIN EXECUTION
# ============================================================

def main():
    """Main execution."""
    
    print("="*70)
    print("MODEL VISUALIZATION WITH ANTI-OVERFITTING PARAMETER SELECTION")
    print("="*70)
    
    # File paths (adjust as needed)
    predictions_file = "./week4_simple_models/predictions_Berlin.csv"  # Your predictions CSV
    features_file = "features_Berlin.csv"  # Your features CSV
    metrics_file = "./week4_simple_models/exhaustive_grid_search_results_Berlin.json"  # Your metrics JSON
    
    # Load data
    print("\n[1/4] Loading data...")
    data = load_predictions_and_features(predictions_file, features_file)
    metrics = load_model_metrics(metrics_file)
    
    # Select best parameters
    print("\n[2/4] Selecting best parameters (anti-overfitting)...")
    selector = BestParameterSelector()
    xgb_params, xgb_best = selector.select_xgboost_params(metrics)
    rf_params, rf_best = selector.select_rf_params(metrics)
    ridge_params, ridge_best = selector.select_ridge_params(metrics)
    quant_params, quant_best = selector.select_quantile_params(metrics)
    
    # Create visualizations
    print("\n[3/4] Creating visualizations...")
    visualizer = ModelVisualizer(data, metrics)
    
    # Time series plot
    fig1, axes1 = visualizer.create_time_series_plot()
    fig1.savefig('model_timeseries_comparison.png', dpi=300, bbox_inches='tight')
    print("  ✓ Saved: model_timeseries_comparison.png")
    
    # Performance dashboard
    fig2 = visualizer.create_performance_dashboard()
    fig2.savefig('model_performance_dashboard.png', dpi=300, bbox_inches='tight')
    print("  ✓ Saved: model_performance_dashboard.png")
    
    # Save selected parameters to JSON
    print("\n[4/4] Saving selected parameters...")
    selected_params = {
        'selection_criteria': 'Anti-overfitting: low test RMSE, low CV std, good generalization',
        'XGBoost_Bias_Correction': {
            'params': xgb_params,
            'cv_rmse': xgb_best['mean_rmse'],
            'cv_r2': xgb_best['mean_r2'],
            'cv_std_r2': xgb_best['std_r2']
        },
        'RandomForest_UHI': {
            'params': rf_params,
            'cv_rmse': rf_best['mean_rmse'],
            'cv_r2': rf_best['mean_r2'],
            'cv_std_r2': rf_best['std_r2']
        },
        'Ridge_Downscaling': {
            'params': ridge_params,
            'cv_rmse': ridge_best['mean_rmse'],
            'cv_r2': ridge_best['mean_r2'],
            'cv_std_r2': ridge_best['std_r2']
        },
        'Quantile_Regression': {
            'params': quant_params,
            'cv_rmse': quant_best['mean_rmse'],
            'test_coverage_quality': metrics['Quantile_Regression']['test_interval_metrics']
        }
    }
    
    with open('selected_best_parameters.json', 'w') as f:
        json.dump(selected_params, f, indent=2)
    print("  ✓ Saved: selected_best_parameters.json")
    
    print("\n" + "="*70)
    print("VISUALIZATION COMPLETE!")
    print("="*70)
    print("\nGenerated files:")
    print("  1. model_timeseries_comparison.png - Time series plots")
    print("  2. model_performance_dashboard.png - Performance metrics")
    print("  3. selected_best_parameters.json - Best parameters for production")


if __name__ == "__main__":
    main()
